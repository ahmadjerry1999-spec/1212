package com.example.util

import android.content.Context
import android.util.Log

class LocalBackupManager(private val context: Context) {
    private val sharedPrefs = context.getSharedPreferences("local_backup_prefs", Context.MODE_PRIVATE)

    var lastManualBackupTime: Long
        get() = sharedPrefs.getLong("last_manual_backup_time", 0L)
        set(value) = sharedPrefs.edit().putLong("last_manual_backup_time", value).apply()

    var lastAutoBackupTime: Long
        get() = sharedPrefs.getLong("last_auto_backup_time", 0L)
        set(value) = sharedPrefs.edit().putLong("last_auto_backup_time", value).apply()

    var enableWeeklyBackup: Boolean
        get() = sharedPrefs.getBoolean("enable_weekly_backup", false)
        set(value) = sharedPrefs.edit().putBoolean("enable_weekly_backup", value).apply()

    var lastWeeklyBackupTime: Long
        get() = sharedPrefs.getLong("last_weekly_backup_time", 0L)
        set(value) = sharedPrefs.edit().putLong("last_weekly_backup_time", value).apply()

    fun saveSilentBackup(jsonText: String) {
        try {
            val file = java.io.File(context.filesDir, "silent_auto_backup.json")
            val out = java.io.FileOutputStream(file)
            out.write(jsonText.toByteArray())
            out.flush()
            out.close()
            lastAutoBackupTime = System.currentTimeMillis()
        } catch (e: Exception) {
            Log.e("LocalBackupManager", "Error saving silent backup", e)
        }
    }

    fun getSilentBackup(): String? {
        return try {
            val file = java.io.File(context.filesDir, "silent_auto_backup.json")
            if (file.exists()) {
                file.readText()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("LocalBackupManager", "Error reading silent backup", e)
            null
        }
    }
}
