package com.example.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.Patient
import com.example.data.model.Prescription
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {

    private class PdfStyle(context: Context) {
        val sharedPrefs = context.getSharedPreferences("ahmed_optical_prefs", Context.MODE_PRIVATE)
        val shopName = sharedPrefs.getString("pdf_shop_name", "AHMED OPTICAL") ?: "AHMED OPTICAL"
        val shopPhone = sharedPrefs.getString("pdf_shop_phone", "") ?: ""
        val shopAddress = sharedPrefs.getString("pdf_shop_address", "") ?: ""
        val customFooter = sharedPrefs.getString("pdf_custom_footer", "Thank you for your visit!") ?: "Thank you for your visit!"
        val headerStyle = sharedPrefs.getString("pdf_header_style", "Modern Banner") ?: "Modern Banner"
        val accentColorHex = sharedPrefs.getString("pdf_accent_color_hex", "#0A5096") ?: "#0A5096"
        
        val accentColor = try {
            Color.parseColor(accentColorHex)
        } catch (e: Exception) {
            Color.rgb(10, 80, 150)
        }
        
        val lightAccentColor = try {
            val r = Color.red(accentColor)
            val g = Color.green(accentColor)
            val b = Color.blue(accentColor)
            Color.rgb(
                (r * 0.15 + 255 * 0.85).toInt(),
                (g * 0.15 + 255 * 0.85).toInt(),
                (b * 0.15 + 255 * 0.85).toInt()
            )
        } catch (e: Exception) {
            Color.rgb(245, 247, 250)
        }
    }

    private fun drawPdfHeader(
        canvas: Canvas,
        pageWidth: Int,
        yPosStart: Float,
        pdfStyle: PdfStyle,
        titleSuffix: String
    ): Float {
        var yPos = yPosStart
        val xMargin = 40f
        val borderPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        if (pdfStyle.headerStyle == "Modern Banner") {
            val bannerPaint = Paint().apply {
                color = pdfStyle.accentColor
                style = Paint.Style.FILL
            }
            canvas.drawRect(xMargin, yPos, pageWidth - xMargin, yPos + 60f, bannerPaint)
            
            val bannerTitlePaint = Paint().apply {
                color = Color.WHITE
                textSize = 15f
                isFakeBoldText = true
                isAntiAlias = true
            }
            
            val bannerSubPaint = Paint().apply {
                color = Color.WHITE
                textSize = 9f
                isAntiAlias = true
                alpha = 220
            }
            
            val displayTitle = "${pdfStyle.shopName.uppercase(Locale.getDefault())} - $titleSuffix"
            canvas.drawText(displayTitle, xMargin + 15f, yPos + 25f, bannerTitlePaint)
            
            var contactInfo = ""
            if (pdfStyle.shopPhone.isNotBlank()) contactInfo += "📞 ${pdfStyle.shopPhone}"
            if (pdfStyle.shopAddress.isNotBlank()) {
                if (contactInfo.isNotBlank()) contactInfo += "   |   "
                contactInfo += "📍 ${pdfStyle.shopAddress}"
            }
            
            if (contactInfo.isNotBlank()) {
                canvas.drawText(contactInfo, xMargin + 15f, yPos + 45f, bannerSubPaint)
            }
            
            yPos += 85f
        } else if (pdfStyle.headerStyle == "Elegant Minimal") {
            val minimalTitlePaint = Paint().apply {
                color = pdfStyle.accentColor
                textSize = 18f
                isFakeBoldText = true
                isAntiAlias = true
            }
            
            val minimalSubPaint = Paint().apply {
                color = Color.rgb(100, 100, 100)
                textSize = 9f
                isAntiAlias = true
            }
            
            val displayTitle = "${pdfStyle.shopName.uppercase(Locale.getDefault())} - $titleSuffix"
            canvas.drawText(displayTitle, xMargin, yPos + 20f, minimalTitlePaint)
            
            var contactInfo = ""
            if (pdfStyle.shopPhone.isNotBlank()) contactInfo += "Phone: ${pdfStyle.shopPhone}"
            if (pdfStyle.shopAddress.isNotBlank()) {
                if (contactInfo.isNotBlank()) contactInfo += "   •   "
                contactInfo += "Address: ${pdfStyle.shopAddress}"
            }
            
            if (contactInfo.isNotBlank()) {
                canvas.drawText(contactInfo, xMargin, yPos + 38f, minimalSubPaint)
            }
            
            yPos += 46f
            val linePaint = Paint().apply {
                color = pdfStyle.accentColor
                strokeWidth = 2f
                style = Paint.Style.STROKE
            }
            canvas.drawLine(xMargin, yPos, pageWidth - xMargin, yPos, linePaint)
            yPos += 25f
        } else { // Classic Border
            val classicTitlePaint = Paint().apply {
                color = pdfStyle.accentColor
                textSize = 16f
                isFakeBoldText = true
                isAntiAlias = true
            }
            val displayTitle = "${pdfStyle.shopName} - $titleSuffix"
            canvas.drawText(displayTitle, xMargin, yPos + 15f, classicTitlePaint)
            
            var infoY = yPos + 30f
            val infoPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 9f
                isAntiAlias = true
            }
            if (pdfStyle.shopPhone.isNotBlank()) {
                canvas.drawText("Phone: ${pdfStyle.shopPhone}", xMargin, infoY, infoPaint)
                infoY += 12f
            }
            if (pdfStyle.shopAddress.isNotBlank()) {
                canvas.drawText("Address: ${pdfStyle.shopAddress}", xMargin, infoY, infoPaint)
                infoY += 12f
            }
            
            yPos = infoY + 10f
            canvas.drawLine(xMargin, yPos, pageWidth - xMargin, yPos, borderPaint)
            yPos += 25f
        }
        return yPos
    }

    private fun drawPdfFooter(
        canvas: Canvas,
        pageWidth: Int,
        pageHeight: Int,
        pdfStyle: PdfStyle
    ) {
        val xMargin = 40f
        val bottomY = pageHeight - 50f
        
        val borderPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        
        val shopPaint = Paint().apply {
            color = pdfStyle.accentColor
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        canvas.drawLine(xMargin, bottomY - 15f, pageWidth - xMargin, bottomY - 15f, borderPaint)
        canvas.drawText(pdfStyle.shopName, xMargin, bottomY, shopPaint)
        
        if (pdfStyle.customFooter.isNotBlank()) {
            val footerPaint = Paint().apply {
                color = Color.GRAY
                textSize = 9f
                isAntiAlias = true
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
            }
            val shopNameWidth = shopPaint.measureText(pdfStyle.shopName)
            canvas.drawText(" |  ${pdfStyle.customFooter}", xMargin + shopNameWidth + 4f, bottomY, footerPaint)
        }
    }

    fun generatePatientReportPdf(
        context: Context,
        patient: Patient,
        prescriptions: List<Prescription>
    ): Uri? {
        val pdfDocument = PdfDocument()
        val pageWidth = 595 // A4 standard width in points (1/72 inch)
        val pageHeight = 842 // A4 standard height in points (1/72 inch)

        val pdfStyle = PdfStyle(context)

        // Setup Paints
        val titlePaint = Paint().apply {
            color = pdfStyle.accentColor
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val sectionHeaderPaint = Paint().apply {
            color = Color.rgb(40, 40, 40)
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isAntiAlias = true
        }

        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val tableHeaderBgPaint = Paint().apply {
            color = pdfStyle.accentColor
            style = Paint.Style.FILL
        }

        val stripeBgPaint = Paint().apply {
            color = pdfStyle.lightAccentColor
            style = Paint.Style.FILL
        }

        // We can draw multiple pages if needed, but we start with Page 1
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        var yPos = 40f
        val xMargin = 40f
        val playableWidth = pageWidth - (xMargin * 2)

        // Draw Custom Header
        yPos = drawPdfHeader(canvas, pageWidth, yPos, pdfStyle, "PATIENT RECORD")

        // Draw Patient Personal Details
        canvas.drawText("PATIENT PROFILE", xMargin, yPos, sectionHeaderPaint)
        yPos += 15f
        
        val details = listOf(
            "Full Name: " to patient.fullName,
            "Phone Number: " to patient.phoneNumber,
            "Date of Birth: " to patient.dateOfBirth
        )
        
        for ((label, valText) in details) {
            canvas.drawText(label, xMargin, yPos, boldTextPaint)
            val textWidth = boldTextPaint.measureText(label)
            canvas.drawText(valText, xMargin + textWidth + 5f, yPos, textPaint)
            yPos += 16f
        }
        
        yPos += 15f
        canvas.drawLine(xMargin, yPos, pageWidth - xMargin, yPos, borderPaint)
        yPos += 25f

        // Draw Prescription History Header
        canvas.drawText("PRESCRIPTION & ORDER HISTORY", xMargin, yPos, sectionHeaderPaint)
        yPos += 20f

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

        if (prescriptions.isEmpty()) {
            canvas.drawText("No prescription records found for this patient.", xMargin, yPos, textPaint)
        } else {
            for ((index, pres) in prescriptions.withIndex()) {
                // Check if we need to pagination (leaving 80f for bottom padding)
                if (yPos > pageHeight - 120f) {
                    drawPdfFooter(canvas, pageWidth, pageHeight, pdfStyle)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    yPos = 40f

                    yPos = drawPdfHeader(canvas, pageWidth, yPos, pdfStyle, "PATIENT RECORD (CONT.)")
                }

                // Draw visit details header
                val dateStr = dateFormat.format(Date(pres.dateMillis))
                canvas.drawText("Visit #${index + 1} - Date: $dateStr", xMargin, yPos, boldTextPaint)
                yPos += 12f

                // Draw Table containing prescription
                val tableY = yPos
                val rowHeight = 18f
                
                // Table header background
                canvas.drawRect(xMargin, tableY, pageWidth - xMargin, tableY + rowHeight, tableHeaderBgPaint)
                canvas.drawLine(xMargin, tableY, pageWidth - xMargin, tableY, borderPaint)
                canvas.drawLine(xMargin, tableY + rowHeight, pageWidth - xMargin, tableY + rowHeight, borderPaint)

                // Headings
                val colWidths = floatArrayOf(80f, 85f, 85f, 85f, 85f, 95f) // Total 515 (fits 595 - 80 margin perfectly)
                val headings = arrayOf("Eye", "SPH", "CYL", "AXIS", "ADD", "PD")
                var colX = xMargin
                for (i in headings.indices) {
                    canvas.drawText(headings[i], colX + 5f, tableY + 12f, tableHeaderPaint)
                    colX += colWidths[i]
                }

                // Row 1: OD (Right)
                val odY = tableY + rowHeight
                canvas.drawRect(xMargin, odY, pageWidth - xMargin, odY + rowHeight, stripeBgPaint)
                
                val odValues = arrayOf(
                    "OD (Right)",
                    pres.odSph?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.odCyl?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.odAxis?.toString() ?: "—",
                    pres.odAdd?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.odPd?.let { String.format(Locale.getDefault(), "%.1f", it) } ?: "—"
                )
                colX = xMargin
                for (i in odValues.indices) {
                    val paint = if (i == 0) boldTextPaint else textPaint
                    canvas.drawText(odValues[i], colX + 5f, odY + 12f, paint)
                    colX += colWidths[i]
                }
                canvas.drawLine(xMargin, odY + rowHeight, pageWidth - xMargin, odY + rowHeight, borderPaint)

                // Row 2: OS (Left)
                val osY = odY + rowHeight
                val osValues = arrayOf(
                    "OS (Left)",
                    pres.osSph?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.osCyl?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.osAxis?.toString() ?: "—",
                    pres.osAdd?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "—",
                    pres.osPd?.let { String.format(Locale.getDefault(), "%.1f", it) } ?: "—"
                )
                colX = xMargin
                for (i in osValues.indices) {
                    val paint = if (i == 0) boldTextPaint else textPaint
                    canvas.drawText(osValues[i], colX + 5f, osY + 12f, paint)
                    colX += colWidths[i]
                }
                canvas.drawLine(xMargin, osY + rowHeight, pageWidth - xMargin, osY + rowHeight, borderPaint)

                // Draw Vertical lines for table
                var vertX = xMargin
                for (i in 0..colWidths.size) {
                    canvas.drawLine(vertX, tableY, vertX, osY + rowHeight, borderPaint)
                    if (i < colWidths.size) {
                        vertX += colWidths[i]
                    }
                }

                yPos = osY + rowHeight + 15f

                // Draw Order details: Frame & Lens
                canvas.drawText("Order Selection: ", xMargin, yPos, boldTextPaint)
                val orderLabelWidth = boldTextPaint.measureText("Order Selection: ")
                canvas.drawText("Frame: ${pres.frameModel ?: "—"}  |  Lens: ${pres.lensType ?: "—"}", xMargin + orderLabelWidth, yPos, textPaint)
                yPos += 14f

                if (!pres.notes.isNullOrBlank()) {
                    canvas.drawText("Notes: ", xMargin, yPos, boldTextPaint)
                    val notesLabelWidth = boldTextPaint.measureText("Notes: ")
                    canvas.drawText(pres.notes, xMargin + notesLabelWidth, yPos, textPaint)
                    yPos += 14f
                }

                yPos += 20f // Spacing between visits
            }
        }

        drawPdfFooter(canvas, pageWidth, pageHeight, pdfStyle)
        pdfDocument.finishPage(page)

        // Save PDF to cache or files directory
        return try {
            val cacheFile = File(context.cacheDir, "patient_${patient.id}_record.pdf")
            val outputStream = FileOutputStream(cacheFile)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()
            
            // Get secure URI using FileProvider configure authority '${applicationId}.fileprovider'
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            null
        }
    }

    fun generateSinglePrescriptionPdf(
        context: Context,
        patient: Patient,
        prescription: Prescription
    ): Uri? {
        val pdfDocument = PdfDocument()
        val pageWidth = 595 // A4 standard width
        val pageHeight = 842 // A4 standard height

        val pdfStyle = PdfStyle(context)

        // Setup Paints
        val titlePaint = Paint().apply {
            color = pdfStyle.accentColor
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val sectionHeaderPaint = Paint().apply {
            color = Color.rgb(40, 40, 40)
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isAntiAlias = true
        }

        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val tableHeaderBgPaint = Paint().apply {
            color = pdfStyle.accentColor
            style = Paint.Style.FILL
        }

        val stripeBgPaint = Paint().apply {
            color = pdfStyle.lightAccentColor
            style = Paint.Style.FILL
        }

        val shopPaint = Paint().apply {
            color = pdfStyle.accentColor
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        var yPos = 40f
        val xMargin = 40f

        // Draw Custom Header
        yPos = drawPdfHeader(canvas, pageWidth, yPos, pdfStyle, "OPTICAL PRESCRIPTION")

        // Patient Details
        canvas.drawText("PATIENT DETAILS", xMargin, yPos, sectionHeaderPaint)
        yPos += 15f

        val details = listOf(
            "Patient Name: " to patient.fullName,
            "Date of Birth: " to patient.dateOfBirth,
            "Phone Number: " to patient.phoneNumber
        )

        for ((label, valText) in details) {
            canvas.drawText(label, xMargin, yPos, boldTextPaint)
            val textWidth = boldTextPaint.measureText(label)
            canvas.drawText(valText, xMargin + textWidth + 5f, yPos, textPaint)
            yPos += 16f
        }

        yPos += 15f
        canvas.drawLine(xMargin, yPos, pageWidth - xMargin, yPos, borderPaint)
        yPos += 25f

        // Prescription SPH, CYL, AXIS, ADD, PD, VABC
        canvas.drawText("PRESCRIPTION DETAILS", xMargin, yPos, sectionHeaderPaint)
        yPos += 20f

        val tableY = yPos
        val rowHeight = 22f

        // Draw Table Header
        canvas.drawRect(xMargin, tableY, pageWidth - xMargin, tableY + rowHeight, tableHeaderBgPaint)
        canvas.drawLine(xMargin, tableY, pageWidth - xMargin, tableY, borderPaint)
        canvas.drawLine(xMargin, tableY + rowHeight, pageWidth - xMargin, tableY + rowHeight, borderPaint)

        // Column widths - total 515 (595 - 80 margin)
        val colWidths = floatArrayOf(80f, 85f, 85f, 85f, 85f, 95f)
        val headings = arrayOf("Eye", "SPH", "CYL", "AXIS", "ADD", "PD")
        var colX = xMargin
        for (i in headings.indices) {
            canvas.drawText(headings[i], colX + 5f, tableY + 15f, tableHeaderPaint)
            colX += colWidths[i]
        }

        val formatSph = { v: Double? -> if (v == null || v == 0.0) "P" else if (v > 0) String.format(java.util.Locale.US, "+%.2f", v) else String.format(java.util.Locale.US, "%.2f", v) }
        val formatCyl = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%.2f", v) }
        val formatAdd = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "+%.2f", v) }
        val formatAxis = { v: Int? -> v?.toString() ?: "0" }
        val formatPd = { v: Double? -> v?.let { String.format(java.util.Locale.US, "%.0f", it) } ?: "0" }
        val formatVabc = { v: String? -> if (v.isNullOrBlank()) "Not recorded" else v }

        // Row 1: OD (Right)
        val odY = tableY + rowHeight
        canvas.drawRect(xMargin, odY, pageWidth - xMargin, odY + rowHeight, stripeBgPaint)
        val odValues = arrayOf(
            "OD (Right)",
            formatSph(prescription.odSph),
            formatCyl(prescription.odCyl),
            formatAxis(prescription.odAxis),
            formatAdd(prescription.odAdd),
            formatPd(prescription.odPd)
        )
        colX = xMargin
        for (i in odValues.indices) {
            val paint = if (i == 0) boldTextPaint else textPaint
            canvas.drawText(odValues[i], colX + 5f, odY + 15f, paint)
            colX += colWidths[i]
        }
        canvas.drawLine(xMargin, odY + rowHeight, pageWidth - xMargin, odY + rowHeight, borderPaint)

        // Row 2: OS (Left)
        val osY = odY + rowHeight
        val osValues = arrayOf(
            "OS (Left)",
            formatSph(prescription.osSph),
            formatCyl(prescription.osCyl),
            formatAxis(prescription.osAxis),
            formatAdd(prescription.osAdd),
            formatPd(prescription.osPd)
        )
        colX = xMargin
        for (i in osValues.indices) {
            val paint = if (i == 0) boldTextPaint else textPaint
            canvas.drawText(osValues[i], colX + 5f, osY + 15f, paint)
            colX += colWidths[i]
        }
        canvas.drawLine(xMargin, osY + rowHeight, pageWidth - xMargin, osY + rowHeight, borderPaint)

        // Draw Vertical grid lines
        var vertX = xMargin
        for (i in 0..colWidths.size) {
            canvas.drawLine(vertX, tableY, vertX, osY + rowHeight, borderPaint)
            if (i < colWidths.size) {
                vertX += colWidths[i]
            }
        }

        yPos = osY + rowHeight + 25f

        // VABC display
        canvas.drawText("VISUAL ACUITY / پشکنینی هێزی بینین", xMargin, yPos, sectionHeaderPaint)
        yPos += 18f

        val formatVaVal = { v: String? -> if (v.isNullOrBlank()) "—" else v }

        val odVaLine = "Right Eye (OD) VABC: ${formatVaVal(prescription.odVabc)}"
        canvas.drawText(odVaLine, xMargin, yPos, textPaint)
        yPos += 15f

        val osVaLine = "Left Eye (OS) VABC: ${formatVaVal(prescription.osVabc)}"
        canvas.drawText(osVaLine, xMargin, yPos, textPaint)
        yPos += 18f

        val binocularVaLine = "Binocular VABC (دوو چاو پێکەوە): ${formatVaVal(prescription.binocularVabc)}"
        canvas.drawText(binocularVaLine, xMargin, yPos, boldTextPaint)
        yPos += 25f

        val hasObjective = !prescription.autorefractionReceipt.isNullOrBlank() || 
                !prescription.keratometry.isNullOrBlank() ||
                !prescription.odAutorefractionReceipt.isNullOrBlank() ||
                !prescription.odKeratometry.isNullOrBlank() ||
                !prescription.osAutorefractionReceipt.isNullOrBlank() ||
                !prescription.osKeratometry.isNullOrBlank()

        if (hasObjective) {
            canvas.drawText("OBJECTIVE REFRACTOMETRY / پشکنینی کۆمپیوتەری چاو", xMargin, yPos, sectionHeaderPaint)
            yPos += 18f
            if (!prescription.autorefractionReceipt.isNullOrBlank()) {
                val autoLine = "Autorefraction Reading / کۆمپیوتەر (Unified): ${prescription.autorefractionReceipt}"
                canvas.drawText(autoLine, xMargin, yPos, textPaint)
                yPos += 15f
            }
            if (!prescription.keratometry.isNullOrBlank()) {
                val kLine = "Keratometry / کەرەتۆمەتری (Unified): ${prescription.keratometry}"
                canvas.drawText(kLine, xMargin, yPos, textPaint)
                yPos += 15f
            }
            if (!prescription.odAutorefractionReceipt.isNullOrBlank() || !prescription.odKeratometry.isNullOrBlank()) {
                val odLine = "OD (Right Eye): Autoref: ${formatVaVal(prescription.odAutorefractionReceipt)} | Keratometry (K1/K2): ${formatVaVal(prescription.odKeratometry)}"
                canvas.drawText(odLine, xMargin, yPos, textPaint)
                yPos += 15f
            }
            if (!prescription.osAutorefractionReceipt.isNullOrBlank() || !prescription.osKeratometry.isNullOrBlank()) {
                val osLine = "OS (Left Eye):  Autoref: ${formatVaVal(prescription.osAutorefractionReceipt)} | Keratometry (K1/K2): ${formatVaVal(prescription.osKeratometry)}"
                canvas.drawText(osLine, xMargin, yPos, textPaint)
                yPos += 15f
            }
        }

        // Draw Custom Footer
        drawPdfFooter(canvas, pageWidth, pageHeight, pdfStyle)

        pdfDocument.finishPage(page)

        return try {
            val cacheFile = File(context.cacheDir, "prescription_${prescription.id}.pdf")
            val outputStream = FileOutputStream(cacheFile)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            null
        }
    }
}
