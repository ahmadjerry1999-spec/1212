package com.example.data.repository

import com.example.data.db.PatientDao
import com.example.data.model.Patient
import com.example.data.model.Prescription
import kotlinx.coroutines.flow.Flow

class OpticalRepository(private val patientDao: PatientDao) {

    val allPatients: Flow<List<Patient>> = patientDao.getAllPatients()
    
    val allPrescriptions: Flow<List<Prescription>> = patientDao.getAllPrescriptions()

    fun searchPatients(query: String): Flow<List<Patient>> {
        return if (query.isBlank()) {
            patientDao.getAllPatients()
        } else {
            patientDao.searchPatients("%$query%")
        }
    }

    fun getPatientById(id: Long): Flow<Patient?> = patientDao.getPatientById(id)

    suspend fun insertPatient(patient: Patient): Long = patientDao.insertPatient(patient)

    suspend fun getPatientCount(): Int = patientDao.getPatientCount()

    suspend fun deleteAllPatients() = patientDao.deleteAllPatients()

    suspend fun deletePatient(patient: Patient) = patientDao.deletePatient(patient)

    fun getPrescriptionsForPatient(patientId: Long): Flow<List<Prescription>> =
        patientDao.getPrescriptionsForPatient(patientId)

    suspend fun insertPrescription(prescription: Prescription): Long =
        patientDao.insertPrescription(prescription)

    suspend fun deletePrescriptionById(id: Long) = patientDao.deletePrescriptionById(id)
}
