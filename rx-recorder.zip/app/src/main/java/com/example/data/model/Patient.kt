package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "patients")
data class Patient(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phoneNumber: String,
    val dateOfBirth: String, // String representation e.g. YYYY-MM-DD
    val createdAtMillis: Long = System.currentTimeMillis()
)
