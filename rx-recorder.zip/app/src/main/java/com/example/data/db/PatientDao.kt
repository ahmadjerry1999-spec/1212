package com.example.data.db

import androidx.room.*
import com.example.data.model.Patient
import com.example.data.model.Prescription
import kotlinx.coroutines.flow.Flow

@Dao
interface PatientDao {
    @Query("SELECT * FROM patients ORDER BY fullName ASC")
    fun getAllPatients(): Flow<List<Patient>>

    @Query("SELECT COUNT(*) FROM patients")
    suspend fun getPatientCount(): Int

    @Query("SELECT * FROM patients WHERE fullName LIKE :query OR phoneNumber LIKE :query ORDER BY fullName ASC")
    fun searchPatients(query: String): Flow<List<Patient>>

    @Query("SELECT * FROM patients WHERE id = :id LIMIT 1")
    fun getPatientById(id: Long): Flow<Patient?>

    @Upsert
    suspend fun insertPatient(patient: Patient): Long

    @Query("DELETE FROM patients")
    suspend fun deleteAllPatients()

    @Delete
    suspend fun deletePatient(patient: Patient)

    @Query("SELECT * FROM prescriptions WHERE patientId = :patientId ORDER BY dateMillis DESC")
    fun getPrescriptionsForPatient(patientId: Long): Flow<List<Prescription>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: Prescription): Long

    @Query("DELETE FROM prescriptions WHERE id = :id")
    suspend fun deletePrescriptionById(id: Long)

    @Query("SELECT * FROM prescriptions ORDER BY dateMillis DESC")
    fun getAllPrescriptions(): Flow<List<Prescription>>
}
