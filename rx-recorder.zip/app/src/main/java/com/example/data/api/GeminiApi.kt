package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    val mimeType: String,
    val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Double? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content?
)

@JsonClass(generateAdapter = true)
data class EyeDetailsExtracted(
    val refraction: EyeRefractionExtracted? = null,
    val keratometry: EyeKeratometryExtracted? = null
)

@JsonClass(generateAdapter = true)
data class EyeRefractionExtracted(
    val sphere: Double? = null,
    val cylinder: Double? = null,
    val axis: Int? = null
)

@JsonClass(generateAdapter = true)
data class EyeKeratometryExtracted(
    val k1: Double? = null,
    val k1_axis: Int? = null,
    val k2: Double? = null,
    val k2_axis: Int? = null,
    val delta: Double? = null
)

@JsonClass(generateAdapter = true)
data class ExtractedPrescription(
    val patient_info: PatientInfoExtracted?,
    val prescription: PrescriptionExtracted?,
    val choices: ChoicesExtracted?,
    val right_eye: EyeDetailsExtracted? = null,
    val left_eye: EyeDetailsExtracted? = null,
    val od_autorefraction_receipt: String? = null,
    val od_keratometry: String? = null,
    val os_autorefraction_receipt: String? = null,
    val os_keratometry: String? = null,
    val autorefraction_receipt: String? = null,
    val keratometry: String? = null
)

@JsonClass(generateAdapter = true)
data class PatientInfoExtracted(
    val name: String?,
    val phone: String?
)

@JsonClass(generateAdapter = true)
data class PrescriptionExtracted(
    val right_eye_OD: EyeExtracted?,
    val left_eye_OS: EyeExtracted?,
    val pd: Double?
)

@JsonClass(generateAdapter = true)
data class EyeExtracted(
    val sph: Double?,
    val cyl: Double?,
    val axis: Int?,
    val add: Double?
)

@JsonClass(generateAdapter = true)
data class ChoicesExtracted(
    val frame: String?,
    val lenses: String?
)

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzePrescription(
        inputText: String?,
        imageBitmap: Bitmap?,
        customApiKey: String? = null
    ): ExtractedPrescription? = withContext(Dispatchers.IO) {
        val apiKey = if (!customApiKey.isNullOrBlank()) customApiKey else BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API Key is empty or placeholder")
            throw Exception("Gemini API key is not configured. Please add your GEMINI_API_KEY in the Secrets panel of AI Studio or enter it in the settings section of this app.")
        }

        val systemInstruction = "You are a precise optical order extraction assistant. Extract the patient's name, phone number (clean spaces and add standard country code if missing, e.g. use + for international format), eye prescription details (SPH, CYL, AXIS, ADD, PD). " +
                "CRITICAL EXTRACTION REQUIREMENT: For both OD (Right Eye) and OS (Left Eye) Autorefraction and Keratometry (K-readings) printed slips or images: diagnostic machinery often prints multiple consecutive measurement rows followed by an Average (typically labeled 'AVG', 'AV', or 'A'). You MUST ONLY extract the 'AVG' (Average) value line. Do not extract raw individual measurement rows. " +
                "Additionally, extract Keratometry (K-readings) for the Right and Left eyes only if they are present in the text/image. For Keratometry, extract k1, k1_axis, k2, k2_axis, and delta (the difference |k1 - k2|). Fill in the requested JSON structure. If fields are omitted, use null."

        val parts = mutableListOf<Part>()
        if (!inputText.isNullOrBlank()) {
            parts.add(Part(text = "Optical raw data contents:\n$inputText"))
        }
        if (imageBitmap != null) {
            val base64Image = imageBitmap.toBase64()
            parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image)))
        }

        if (parts.isEmpty()) {
            throw Exception("No data submitted. Please enter some text or take/upload a photo first.")
        }

        parts.add(Part(text = "Strictly output the data matching this JSON Schema. If values are missing, output null. Structure:\n" +
                "{\n" +
                "  \"patient_info\": { \"name\": string or null, \"phone\": string or null },\n" +
                "  \"right_eye\": {\n" +
                "    \"refraction\": { \"sphere\": double or null, \"cylinder\": double or null, \"axis\": int or null },\n" +
                "    \"keratometry\": { \"k1\": double or null, \"k1_axis\": int or null, \"k2\": double or null, \"k2_axis\": int or null, \"delta\": double or null }\n" +
                "  },\n" +
                "  \"left_eye\": {\n" +
                "    \"refraction\": { \"sphere\": double or null, \"cylinder\": double or null, \"axis\": int or null },\n" +
                "    \"keratometry\": { \"k1\": double or null, \"k1_axis\": int or null, \"k2\": double or null, \"k2_axis\": int or null, \"delta\": double or null }\n" +
                "  },\n" +
                "  \"prescription\": {\n" +
                "    \"right_eye_OD\": { \"sph\": double or null, \"cyl\": double or null, \"axis\": int or null, \"add\": double or null },\n" +
                "    \"left_eye_OS\": { \"sph\": double or null, \"cyl\": double or null, \"axis\": int or null, \"add\": double or null },\n" +
                "    \"pd\": double or null\n" +
                "  },\n" +
                "  \"choices\": { \"frame\": string or null, \"lenses\": string or null },\n" +
                "  \"od_autorefraction_receipt\": string or null,\n" +
                "  \"od_keratometry\": string or null,\n" +
                "  \"os_autorefraction_receipt\": string or null,\n" +
                "  \"os_keratometry\": string or null\n" +
                "}"))

        val requestObj = GenerateContentRequest(
            contents = listOf(Content(parts = parts)),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.1
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
        )

        val requestAdapter = moshi.adapter(GenerateContentRequest::class.java)
        val responseAdapter = moshi.adapter(GenerateContentResponse::class.java)
        val extractedAdapter = moshi.adapter(ExtractedPrescription::class.java)

        try {
            val jsonRequestBody = requestAdapter.toJson(requestObj)
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(jsonRequestBody.toRequestBody("application/json".toMediaType()))
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "API error code: ${response.code}, body: $errBody")
                    throw Exception("Gemini API call failed with code ${response.code}: $errBody")
                }

                val bodyStr = response.body?.string()
                if (bodyStr.isNullOrEmpty()) {
                    throw Exception("Gemini API returned an empty body response.")
                }

                val parsedResponse = responseAdapter.fromJson(bodyStr)
                val rawTextResponse = parsedResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (rawTextResponse.isNullOrEmpty()) {
                    Log.e(TAG, "Empty text in Gemini response candidate parts")
                    throw Exception("Gemini did not return any parsed text. The image or text might be unreadable.")
                }

                Log.d(TAG, "Raw extracted JSON: $rawTextResponse")
                return@withContext extractedAdapter.fromJson(rawTextResponse)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during analyzePrescription", e)
            throw e
        }
    }
}
