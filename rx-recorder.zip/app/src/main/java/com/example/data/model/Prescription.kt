package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "prescriptions",
    foreignKeys = [
        ForeignKey(
            entity = Patient::class,
            parentColumns = ["id"],
            childColumns = ["patientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["patientId"])]
)
data class Prescription(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val patientId: Long,
    val dateMillis: Long = System.currentTimeMillis(),

    // Right Eye (OD)
    val odSph: Double? = null,
    val odCyl: Double? = null,
    val odAxis: Int? = null,
    val odAdd: Double? = null,
    val odPd: Double? = null,

    // Left Eye (OS)
    val osSph: Double? = null,
    val osCyl: Double? = null,
    val osAxis: Int? = null,
    val osAdd: Double? = null,
    val osPd: Double? = null,

    // Visual Acuity (OD)
    val odVasc: String? = null,
    val odVscc: String? = null,
    val odVabc: String? = null,
    val odVaPinhole: String? = null,

    // Visual Acuity (OS)
    val osVasc: String? = null,
    val osVscc: String? = null,
    val osVabc: String? = null,
    val osVaPinhole: String? = null,

    // Binocular Visual Acuity
    val binocularVabc: String? = null,

    // Order Choices
    val frameModel: String? = null,
    val lensType: String? = null,
    val notes: String? = null,

    // Autorefraction Receipt & Keratometry
    val autorefractionReceipt: String? = null,
    val keratometry: String? = null,
    val odAutorefractionReceipt: String? = null,
    val odKeratometry: String? = null,
    val osAutorefractionReceipt: String? = null,
    val osKeratometry: String? = null,
    val photoUri: String? = null
)
