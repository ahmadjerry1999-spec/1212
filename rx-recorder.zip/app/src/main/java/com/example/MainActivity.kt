package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import com.example.data.db.AppDatabase
import com.example.data.repository.OpticalRepository
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NewPrescriptionScreen
import com.example.ui.screens.PatientProfileScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.OpticalViewModel
import com.example.ui.viewmodel.OpticalViewModelFactory

sealed class Screen {
    object Dashboard : Screen()
    data class Profile(val patientId: Long) : Screen()
    data class NewPrescription(val patientId: Long, val prescriptionId: Long? = null) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Set up Room database and domain repositories
        val database = AppDatabase.getDatabase(this)
        val repository = OpticalRepository(database.patientDao())

        // Set up ViewModel Provider using Factory
        val viewModel = ViewModelProvider(
            this,
            OpticalViewModelFactory(repository)
        )[OpticalViewModel::class.java]

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }

                Surface(modifier = Modifier.fillMaxSize()) {
                    Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                        when (screen) {
                            is Screen.Dashboard -> {
                                DashboardScreen(
                                    viewModel = viewModel,
                                    onNavigateToProfile = { id ->
                                        currentScreen = Screen.Profile(id)
                                    }
                                )
                            }
                            is Screen.Profile -> {
                                PatientProfileScreen(
                                    viewModel = viewModel,
                                    patientId = screen.patientId,
                                    onNavigateBack = {
                                        currentScreen = Screen.Dashboard
                                    },
                                    onNavigateToNewPrescription = { id, rxId ->
                                        currentScreen = Screen.NewPrescription(id, rxId)
                                    }
                                )
                            }
                            is Screen.NewPrescription -> {
                                NewPrescriptionScreen(
                                    viewModel = viewModel,
                                    patientId = screen.patientId,
                                    prescriptionId = screen.prescriptionId,
                                    onNavigateBack = {
                                        currentScreen = Screen.Profile(screen.patientId)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
fun Greeting(name: String, modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    androidx.compose.material3.Text(text = "Hello $name!", modifier = modifier)
}

