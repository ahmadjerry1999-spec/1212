package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme =
  lightColorScheme(
    primary = OpticPrimary,
    onPrimary = OpticOnPrimary,
    primaryContainer = OpticPrimaryContainer,
    onPrimaryContainer = OpticOnPrimaryContainer,
    secondary = OpticSecondary,
    onSecondary = OpticOnSecondary,
    secondaryContainer = OpticSecondaryContainer,
    onSecondaryContainer = OpticOnSecondaryContainer,
    background = OpticBackground,
    onBackground = OpticOnBackground,
    surface = OpticSurface,
    onSurface = OpticOnSurface,
    surfaceVariant = OpticSurfaceVariant,
    onSurfaceVariant = OpticOnSurfaceVariant,
    outline = OpticOutline,
    outlineVariant = OpticOutlineVariant
  )

private val DarkColorScheme = LightColorScheme // Keep consistent for professional branding

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamicColor by default to guarantee our pristine custom High Density design theme colors take exclusive precedence
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }


  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
