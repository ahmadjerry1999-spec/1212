package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Patient
import com.example.data.model.Prescription
import com.example.ui.viewmodel.OpticalViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: OpticalViewModel,
    onNavigateToProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    
    LaunchedEffect(Unit) {
        viewModel.checkAndTriggerWeeklyBackup(context)
    }

    val searchQuery by viewModel.searchQuery.collectAsState()
    val patients by viewModel.patients.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var patientToEdit by remember { mutableStateOf<Patient?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            modifier = Modifier.size(36.dp),
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                  Text(
                                      text = "RX",
                                      color = MaterialTheme.colorScheme.onPrimary,
                                      fontSize = 15.sp,
                                      fontWeight = FontWeight.Bold
                                  )
                            }
                        }
                        Column {
                            Text(
                                text = "RX Recorder",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "High Density EHR Tracker",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                actions = {
                    IconButton(
                        onClick = { showSettings = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.testTag("add_patient_fab"),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add New Patient"
                )
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("patient_search_bar"),
                placeholder = { Text("Search patient or phone...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear search"
                            )
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Patient List Section Title
            Text(
                text = if (searchQuery.isEmpty()) "All Patients" else "Search Results (${patients.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (patients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "No patients found",
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outlineVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (searchQuery.isEmpty()) "No patients registered yet" else "No matching patients found",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isEmpty()) "Tap the + button to add your first patient records" else "Try searching with a different name or phone number",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.fillMaxWidth(0.8f),
                            lineHeight = 18.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(patients, key = { it.id }) { patient ->
                        PatientItemCard(
                            patient = patient,
                            onClick = { onNavigateToProfile(patient.id) },
                            onEditClick = { patientToEdit = patient }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddPatientDialog(
            patient = null,
            onDismiss = { showAddDialog = false },
            onAddPatient = { name, phone, dob ->
                viewModel.addPatient(context, id = 0, name, phone, dob) { newId ->
                    showAddDialog = false
                    onNavigateToProfile(newId)
                }
            }
        )
    }

    if (patientToEdit != null) {
        AddPatientDialog(
            patient = patientToEdit,
            onDismiss = { patientToEdit = null },
            onAddPatient = { name, phone, dob ->
                viewModel.addPatient(context, id = patientToEdit!!.id, name, phone, dob) { savedId ->
                    patientToEdit = null
                }
            }
        )
    }

    if (showSettings) {
        SettingsDialog(
            viewModel = viewModel,
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
fun PatientItemCard(
    patient: Patient,
    onClick: () -> Unit,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("patient_card_${patient.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.primary
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = patient.fullName.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = patient.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Phone",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = patient.phoneNumber,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = "DOB",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "DOB: ${patient.dateOfBirth}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            IconButton(
                onClick = onEditClick,
                modifier = Modifier.testTag("edit_patient_button_${patient.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Patient",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Icon(
                imageVector = Icons.Default.KeyboardArrowRight,
                contentDescription = "View Profile",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPatientDialog(
    patient: Patient? = null,
    onDismiss: () -> Unit,
    onAddPatient: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(patient?.fullName ?: "") }
    var phone by remember { mutableStateOf(patient?.phoneNumber ?: "") }
    var dob by remember { mutableStateOf(patient?.dateOfBirth ?: "") }

    var nameError by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf(false) }
    var dobError by remember { mutableStateOf(false) }

    var showDatePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (patient == null) "Add New Patient" else "Edit Patient Profile",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = false
                    },
                    label = { Text("Full Name") },
                    isError = nameError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_patient_name")
                )
                if (nameError) {
                    Text(
                        text = "Name is required",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp
                    )
                }

                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        phoneError = false
                    },
                    label = { Text("Phone Number") },
                    isError = phoneError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_patient_phone"),
                    placeholder = { Text("e.g. 07701234567 or +964...") }
                )
                if (phoneError) {
                    Text(
                        text = "Valid phone number is required",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp
                    )
                }

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = dob,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Date of Birth") },
                        placeholder = { Text("Select date") },
                        isError = dobError,
                        trailingIcon = {
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Select DOB")
                        },
                        modifier = Modifier.fillMaxWidth().testTag("add_patient_dob")
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable { showDatePicker = true }
                    )
                }
                if (dobError) {
                    Text(
                        text = "DOB date is required",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) nameError = true
                    if (phone.isBlank()) phoneError = true
                    if (dob.isBlank()) dobError = true

                    if (!nameError && !phoneError && !dobError) {
                        onAddPatient(name, phone, dob)
                    }
                },
                modifier = Modifier.testTag("submit_add_patient")
            ) {
                Text(if (patient == null) "Add Patient" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )

    if (showDatePicker) {
        DatePickerDialogSample(
            onDateSelected = { selectedDate ->
                dob = selectedDate
                dobError = false
            },
            onDismiss = { showDatePicker = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerDialogSample(
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val datePickerState = rememberDatePickerState(
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                return utcTimeMillis <= System.currentTimeMillis()
            }
        }
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val date = java.util.Date(millis)
                        val formatCorrect = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                        formatCorrect.timeZone = java.util.TimeZone.getTimeZone("UTC")
                        onDateSelected(formatCorrect.format(date))
                    }
                    onDismiss()
                }
            ) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    ) {
        DatePicker(state = datePickerState)
    }
}

@Composable
fun SettingsDialog(
    viewModel: OpticalViewModel,
    onDismiss: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val allPatients by viewModel.allPatients.collectAsState()
    val allPrescriptions by viewModel.allPrescriptions.collectAsState()

    val sharedPrefs = remember {
        context.getSharedPreferences("ahmed_optical_prefs", android.content.Context.MODE_PRIVATE)
    }
    var autoSaveEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("pref_auto_save", true))
    }

    var pdfShopName by remember {
        mutableStateOf(sharedPrefs.getString("pdf_shop_name", "AHMED OPTICAL") ?: "AHMED OPTICAL")
    }
    var pdfShopPhone by remember {
        mutableStateOf(sharedPrefs.getString("pdf_shop_phone", "") ?: "")
    }
    var pdfShopAddress by remember {
        mutableStateOf(sharedPrefs.getString("pdf_shop_address", "") ?: "")
    }
    var pdfCustomFooter by remember {
        mutableStateOf(sharedPrefs.getString("pdf_custom_footer", "Thank you for your visit!") ?: "Thank you for your visit!")
    }
    var pdfHeaderStyle by remember {
        mutableStateOf(sharedPrefs.getString("pdf_header_style", "Modern Banner") ?: "Modern Banner")
    }
    var pdfAccentColorHex by remember {
        mutableStateOf(sharedPrefs.getString("pdf_accent_color_hex", "#0A5096") ?: "#0A5096")
    }

    var geminiApiKey by remember {
        mutableStateOf(sharedPrefs.getString("gemini_api_key", "") ?: "")
    }

    val savePdfSetting = { key: String, value: String ->
        sharedPrefs.edit().putString(key, value).apply()
    }

    val backupManager = remember { com.example.util.LocalBackupManager(context) }

    var weeklyBackupEnabled by remember {
        mutableStateOf(backupManager.enableWeeklyBackup)
    }
    var lastManualBackup by remember {
        mutableStateOf(backupManager.lastManualBackupTime)
    }
    var lastAutoBackup by remember {
        mutableStateOf(backupManager.lastAutoBackupTime)
    }

    val csvPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            viewModel.importCsv(context, uri) { success, message ->
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    val jsonPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val reader = inputStream.bufferedReader()
                    val jsonContent = reader.readText()
                    inputStream.close()
                    viewModel.importFromJson(jsonContent) { success, message ->
                        if (success) {
                            Toast.makeText(context, "Backup restored successfully!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Toast.makeText(context, "Could not open file", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error reading backup file: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Ahmed Optical Settings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Manage patient database and exports.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // AUTO-SAVE PREFERENCE SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "AUTO-SAVE SETTING",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Auto-save prescription drafts as you type every 3 seconds.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = autoSaveEnabled,
                            onCheckedChange = { isChecked ->
                                autoSaveEnabled = isChecked
                                sharedPrefs.edit().putBoolean("pref_auto_save", isChecked).apply()
                                Toast.makeText(context, if (isChecked) "Auto-save active" else "Auto-save disabled", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("auto_save_settings_switch")
                        )
                    }
                }

                // PDF STYLE CUSTOMIZATION SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "🎨 PDF DESIGN & BRANDING",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Customize the layout, colors, and business info on shared prescription PDFs.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = pdfShopName,
                            onValueChange = {
                                pdfShopName = it
                                savePdfSetting("pdf_shop_name", it)
                            },
                            label = { Text("Shop Name / Banner Title", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.fillMaxWidth().testTag("pdf_shop_name_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = pdfShopPhone,
                                onValueChange = {
                                    pdfShopPhone = it
                                    savePdfSetting("pdf_shop_phone", it)
                                },
                                label = { Text("Contact Phone", fontSize = 11.sp) },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                modifier = Modifier.weight(1f).testTag("pdf_shop_phone_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            OutlinedTextField(
                                value = pdfShopAddress,
                                onValueChange = {
                                    pdfShopAddress = it
                                    savePdfSetting("pdf_shop_address", it)
                                },
                                label = { Text("Shop Address", fontSize = 11.sp) },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                modifier = Modifier.weight(1.2f).testTag("pdf_shop_address_input"),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        OutlinedTextField(
                            value = pdfCustomFooter,
                            onValueChange = {
                                pdfCustomFooter = it
                                savePdfSetting("pdf_custom_footer", it)
                            },
                            label = { Text("Custom Footer Message", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.fillMaxWidth().testTag("pdf_custom_footer_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Text(
                            text = "Header Layout Style",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val styles = listOf("Modern Banner", "Elegant Minimal", "Classic Border")
                            styles.forEach { style ->
                                val selected = pdfHeaderStyle == style
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            pdfHeaderStyle = style
                                            savePdfSetting("pdf_header_style", style)
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp)
                                        .testTag("header_style_chip_${style.replace(" ", "_")}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = style,
                                        fontSize = 11.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Brand Accent Color Theme",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        val colors = listOf(
                            "#0A5096" to "Classic Blue",
                            "#0F623F" to "Dark Emerald",
                            "#057285" to "Ocean Teal",
                            "#5B2C6F" to "Deep Violet",
                            "#7D2232" to "Ruby Rose",
                            "#2C3E50" to "Sleek Dark"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            colors.forEach { (hex, name) ->
                                val selected = pdfAccentColorHex.equals(hex, ignoreCase = true)
                                val borderStroke = if (selected) {
                                    androidx.compose.foundation.BorderStroke(3.dp, MaterialTheme.colorScheme.primary)
                                } else {
                                    androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray)
                                }
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(Color(android.graphics.Color.parseColor(hex)), shape = CircleShape)
                                        .border(borderStroke, shape = CircleShape)
                                        .clickable {
                                            pdfAccentColorHex = hex
                                            savePdfSetting("pdf_accent_color_hex", hex)
                                        }
                                        .testTag("pdf_color_swatch_$name"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (selected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // CSV EXPORT SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "DATABASE EXPORT (CSV)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Total Records: ${allPatients.size} Patients, ${allPrescriptions.size} Prescriptions",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        )

                        Button(
                            onClick = {
                                val csvText = generateCsvString(allPatients, allPrescriptions)
                                shareCsvFile(context, csvText)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("export_csv_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export to Excel (CSV)")
                        }

                        OutlinedButton(
                            onClick = {
                                val csvText = generateCsvString(allPatients, allPrescriptions)
                                copyToClipboard(context, csvText)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("copy_csv_btn"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Copy CSV to Clipboard")
                        }
                    }
                }

                // GOOGLE SHEETS SETUP SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "GOOGLE SHEETS SETUP",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "1. Click 'Export to Excel (CSV)' and save your file.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "2. Open Google Sheets and click File > Import.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "3. Upload the export CSV to sync patient data instantly.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // DATABASE IMPORT SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "DATABASE IMPORT (CSV)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Import local patients & prescriptions database backup from a previously exported CSV file.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = {
                                csvPickerLauncher.launch("text/*")
                            },
                            modifier = Modifier.fillMaxWidth().testTag("import_csv_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Import CSV Backup")
                        }
                    }
                }

                // HIGH SECURITY JSON BACKUP SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "📥 BACKUP & RESTORE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Export or restore your optical records database (patients and prescriptions) of this app via a cross-platform JSON file.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = {
                                viewModel.exportToJson { success, jsonText ->
                                    if (success) {
                                        shareJsonBackup(context, jsonText)
                                        val now = System.currentTimeMillis()
                                        backupManager.lastManualBackupTime = now
                                        lastManualBackup = now
                                    } else {
                                        Toast.makeText(context, jsonText, Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("manual_backup_json_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("📥 Manual Backup (Save to Computer)")
                        }

                        OutlinedButton(
                            onClick = {
                                jsonPickerLauncher.launch("*/*")
                            },
                            modifier = Modifier.fillMaxWidth().testTag("restore_from_file_json_btn"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                        ) {
                            Text("📤 Restore from File (from Computer)")
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Weekly Backup (every 7 days)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Automatically checks & saves a local silent backup every 7 days upon app start.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 12.sp
                                )
                            }
                            Switch(
                                checked = weeklyBackupEnabled,
                                onCheckedChange = { checked ->
                                    weeklyBackupEnabled = checked
                                    backupManager.enableWeeklyBackup = checked
                                },
                                modifier = Modifier.testTag("weekly_backup_switch")
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant)

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "📊 BACKUP STATUS & HISTORY",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 0.5.sp
                            )

                            val formatBackupTime = remember {
                                { timeMs: Long ->
                                    if (timeMs == 0L) "Never"
                                    else {
                                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                                        sdf.format(java.util.Date(timeMs))
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Last manual backup:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = formatBackupTime(lastManualBackup),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Last automatic backup:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = formatBackupTime(lastAutoBackup),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_settings_btn")
            ) {
                Text("Close")
            }
        }
    )
}

private fun generateCsvString(patients: List<Patient>, prescriptions: List<Prescription>): String {
    val patientMap = patients.associateBy { it.id }
    val sb = java.lang.StringBuilder()
    
    sb.append("Patient Name,Phone,Birth Date,R_SPH,R_CYL,R_Axis,L_SPH,L_CYL,L_Axis,ADD,PD,OD_VASC,OD_VSCC,OD_VABC,OD_VAPinhole,OS_VASC,OS_VSCC,OS_VABC,OS_VAPinhole,Binocular_VABC,Autorefraction_Receipt,Keratometry,OD_Autorefraction,OD_Keratometry,OS_Autorefraction,OS_Keratometry,Date of Prescription\n")
    
    val formatSph = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%+.2f", v) }
    val formatCyl = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%.2f", v) }
    val formatAxis = { v: Int? -> v?.toString() ?: "0" }
    val formatAdd = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%+.2f", v) }
    val formatPd = { v: Double? -> v?.let { String.format(java.util.Locale.US, "%.0f", it) } ?: "0" }
    
    for (pres in prescriptions) {
        val patient = patientMap[pres.patientId] ?: continue
        
        val escapedName = "\"${patient.fullName.replace("\"", "\"\"")}\""
        val escapedPhone = "\"${patient.phoneNumber.replace("\"", "\"\"")}\""
        val escapedDob = "\"${patient.dateOfBirth.replace("\"", "\"\"")}\""
        
        val rSph = formatSph(pres.odSph)
        val rCyl = formatCyl(pres.odCyl)
        val rAxis = formatAxis(pres.odAxis)
        
        val lSph = formatSph(pres.osSph)
        val lCyl = formatCyl(pres.osCyl)
        val lAxis = formatAxis(pres.osAxis)
        
        val addSym = formatAdd(pres.odAdd)
        val pdSym = formatPd(pres.odPd)
        
        val odVascText = "\"${(pres.odVasc ?: "").replace("\"", "\"\"")}\""
        val odVsccText = "\"${(pres.odVscc ?: "").replace("\"", "\"\"")}\""
        val odVabcText = "\"${(pres.odVabc ?: "").replace("\"", "\"\"")}\""
        val odVapinholeText = "\"${(pres.odVaPinhole ?: "").replace("\"", "\"\"")}\""

        val osVascText = "\"${(pres.osVasc ?: "").replace("\"", "\"\"")}\""
        val osVsccText = "\"${(pres.osVscc ?: "").replace("\"", "\"\"")}\""
        val osVabcText = "\"${(pres.osVabc ?: "").replace("\"", "\"\"")}\""
        val osVapinholeText = "\"${(pres.osVaPinhole ?: "").replace("\"", "\"\"")}\""

        val binocularVabcText = "\"${(pres.binocularVabc ?: "").replace("\"", "\"\"")}\""

        val autorefractionText = "\"${(pres.autorefractionReceipt ?: "").replace("\"", "\"\"")}\""
        val keratometryText = "\"${(pres.keratometry ?: "").replace("\"", "\"\"")}\""

        val odAutorefractionText = "\"${(pres.odAutorefractionReceipt ?: "").replace("\"", "\"\"")}\""
        val odKeratometryText = "\"${(pres.odKeratometry ?: "").replace("\"", "\"\"")}\""
        val osAutorefractionText = "\"${(pres.osAutorefractionReceipt ?: "").replace("\"", "\"\"")}\""
        val osKeratometryText = "\"${(pres.osKeratometry ?: "").replace("\"", "\"\"")}\""
        
        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(pres.dateMillis))
        val escapedDate = "\"$dateStr\""
        
        sb.append("$escapedName,$escapedPhone,$escapedDob,$rSph,$rCyl,$rAxis,$lSph,$lCyl,$lAxis,$addSym,$pdSym,$odVascText,$odVsccText,$odVabcText,$odVapinholeText,$osVascText,$osVsccText,$osVabcText,$osVapinholeText,$binocularVabcText,$autorefractionText,$keratometryText,$odAutorefractionText,$odKeratometryText,$osAutorefractionText,$osKeratometryText,$escapedDate\n")
    }
    return sb.toString()
}

private fun shareCsvFile(context: android.content.Context, csvText: String) {
    try {
        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val fileName = "ahmed_optical_export_$dateStr.csv"
        val file = java.io.File(context.cacheDir, fileName)
        val out = java.io.FileOutputStream(file)
        out.write(csvText.toByteArray())
        out.flush()
        out.close()
        
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Ahmed Optical Patient Records Export")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Export Patient Records to CSV"))
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context, "Error saving CSV export: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

private fun copyToClipboard(context: android.content.Context, csvText: String) {
    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    val clip = android.content.ClipData.newPlainText("Ahmed Optical CSV Data", csvText)
    clipboard.setPrimaryClip(clip)
    android.widget.Toast.makeText(context, "Database CSV copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
}

private fun shareJsonBackup(context: android.content.Context, jsonText: String) {
    try {
        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val fileName = "optical_shop_backup_$dateStr.json"
        val file = java.io.File(context.cacheDir, fileName)
        val out = java.io.FileOutputStream(file)
        out.write(jsonText.toByteArray())
        out.flush()
        out.close()
        
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Optical Shop JSON Backup")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Download or Save Backup File"))
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context, "Error saving backup: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

