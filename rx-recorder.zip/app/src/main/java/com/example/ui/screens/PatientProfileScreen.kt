package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Patient
import com.example.data.model.Prescription
import com.example.ui.viewmodel.OpticalViewModel
import com.example.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.*
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientProfileScreen(
    viewModel: OpticalViewModel,
    patientId: Long,
    onNavigateBack: () -> Unit,
    onNavigateToNewPrescription: (Long, Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Trigger loading profile info inside the viewmodel
    LaunchedEffect(patientId) {
        viewModel.selectPatient(patientId)
    }

    val patient by viewModel.selectedPatient.collectAsState()
    val prescriptions by viewModel.prescriptions.collectAsState()

    var showDeleteDialog by remember { mutableStateOf(false) }
    var activePdfSharePrescription by remember { mutableStateOf<Prescription?>(null) }
    var prescriptionToDelete by remember { mutableStateOf<Prescription?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Patient Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            patient?.let { p ->
                                val pdfUri = PdfGenerator.generatePatientReportPdf(context, p, prescriptions)
                                if (pdfUri != null) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, pdfUri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Export Patient History PDF"))
                                } else {
                                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.testTag("export_pdf_button")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Export History PDF")
                    }

                    IconButton(
                        onClick = { showDeleteDialog = true },
                        modifier = Modifier.testTag("delete_patient_button")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Patient")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onNavigateToNewPrescription(patientId, null) },
                icon = { Icon(imageVector = Icons.Default.Add, contentDescription = null) },
                text = { Text("New Rx & Order") },
                modifier = Modifier.testTag("new_rx_button"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        },
        modifier = modifier
    ) { paddingValues ->
        if (patient == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val currPatient = patient!!
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Details Card
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    PatientDetailsCard(patient = currPatient)
                }

                // Interactive share / messaging links for latest Rx
                if (prescriptions.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Send Latest Receipt & Rx / ناردنی ئەنجامەکان",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Open messenger with a summary text or directly share the printed PDF receipt.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                // --- Tab 1: Text Summary ---
                                Text(
                                    text = "Text Format / ڕیپۆرتی دەقی",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                MessagingActionRow(
                                    patient = currPatient,
                                    prescription = prescriptions.first(),
                                    viewModel = viewModel,
                                    context = context
                                )

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                Spacer(modifier = Modifier.height(10.dp))

                                // --- Tab 2: PDF Document ---
                                Text(
                                    text = "PDF Document / دۆکیومێنتی PDF",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                PdfMessagingActionRow(
                                    patient = currPatient,
                                    prescription = prescriptions.first(),
                                    context = context
                                )
                            }
                        }
                    }
                }

                // History Title
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Prescription History",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Badge(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ) {
                            Text(
                                text = "${prescriptions.size} Visits",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (prescriptions.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No prescriptions recorded yet",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Tap 'New Rx & Order' below to start.",
                                    color = MaterialTheme.colorScheme.outline,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                } else {
                    items(prescriptions, key = { it.id }) { prescription ->
                        PrescriptionHistoryCard(
                            prescription = prescription,
                            patient = currPatient,
                            viewModel = viewModel,
                            onEdit = { onNavigateToNewPrescription(currPatient.id, prescription.id) },
                            onDelete = { prescriptionToDelete = prescription },
                            onSharePdf = { activePdfSharePrescription = prescription }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp)) // Padding for FAB
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Patient Profile?") },
            text = { Text("Are you sure you want to permanently delete this patient record and all associated prescription history? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        patient?.let { p ->
                            viewModel.deletePatient(p)
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_patient")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (prescriptionToDelete != null) {
        AlertDialog(
            onDismissRequest = { prescriptionToDelete = null },
            title = { Text("Delete Prescription Record?") },
            text = { Text("Are you sure you want to permanently delete this prescription record? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        prescriptionToDelete?.let { rx ->
                            viewModel.deletePrescription(rx.id)
                        }
                        prescriptionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_prescription")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { prescriptionToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (activePdfSharePrescription != null) {
        val currPatient = patient
        if (currPatient != null) {
            AlertDialog(
                onDismissRequest = { activePdfSharePrescription = null },
                title = { Text("Send PDF / ناردنی PDF", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Send prescription PDF directly to patient on WhatsApp, Viber, or Telegram.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Button(
                            onClick = {
                                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, currPatient, activePdfSharePrescription!!)
                                if (pdfUri != null) {
                                    sharePdfViaApp(context, pdfUri, currPatient.phoneNumber, "whatsapp")
                                } else {
                                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                }
                                activePdfSharePrescription = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("WhatsApp PDF", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, currPatient, activePdfSharePrescription!!)
                                if (pdfUri != null) {
                                    sharePdfViaApp(context, pdfUri, currPatient.phoneNumber, "viber")
                                } else {
                                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                }
                                activePdfSharePrescription = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7360F2)),
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Viber PDF", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, currPatient, activePdfSharePrescription!!)
                                if (pdfUri != null) {
                                    sharePdfViaApp(context, pdfUri, currPatient.phoneNumber, "telegram")
                                } else {
                                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                }
                                activePdfSharePrescription = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0088CC)),
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Telegram PDF", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, currPatient, activePdfSharePrescription!!)
                                if (pdfUri != null) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, pdfUri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share Single Prescription PDF"))
                                } else {
                                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                }
                                activePdfSharePrescription = null
                            },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Other / Share Sheet", color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { activePdfSharePrescription = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun PatientDetailsCard(patient: Patient) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("patient_details_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(46.dp),
                        shape = RoundedCornerShape(23.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = patient.fullName.take(1).uppercase(),
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = patient.fullName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = patient.phoneNumber,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    Text(
                        text = "PATIENT REC",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "BORN",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = patient.dateOfBirth,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "CREATED ON",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(patient.createdAtMillis)),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RxParamTableHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(vertical = 8.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Eye", modifier = Modifier.weight(1.2f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
        Text("SPH", modifier = Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, textAlign = TextAlign.Center)
        Text("CYL", modifier = Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, textAlign = TextAlign.Center)
        Text("Axis", modifier = Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, textAlign = TextAlign.Center)
    }
}

// CSS-like class representation for SPH display inside each prescription box
val SphDisplayCssClass = TextStyle(
    fontSize = 11.sp,
    fontWeight = FontWeight.SemiBold
)

@Composable
fun RxParamTableRow(
    label: String,
    sph: Double?,
    cyl: Double?,
    axis: Int?,
    bgColor: Color
) {
    val formatSph = if (sph == null || sph == 0.0) "P" else String.format(Locale.US, "%+.2f", sph)
    val formatCyl = if (cyl == null || cyl == 0.0) "P" else String.format(Locale.US, "%+.2f", cyl)
    val formatAxis = axis?.let { "$it°" } ?: "0"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .padding(vertical = 10.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1.2f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(
            text = formatSph,
            modifier = Modifier.weight(1f),
            style = SphDisplayCssClass,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(formatCyl, modifier = Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
        Text(formatAxis, modifier = Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun PrescriptionHistoryCard(
    prescription: Prescription,
    patient: Patient,
    viewModel: OpticalViewModel,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSharePdf: () -> Unit
) {
    val context = LocalContext.current
    val formattedDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(prescription.dateMillis))

    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("prescription_history_card_${prescription.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = patient.fullName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Visit: $formattedDate",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(24.dp).testTag("edit_rx_${prescription.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit prescription details",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = {
                            onSharePdf()
                        },
                        modifier = Modifier.size(24.dp).testTag("generate_pdf_rx_${prescription.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Generate PDF for prescription",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(24.dp).testTag("delete_rx_${prescription.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete prescription history entry",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))

                    // TABULAR RX PARAMETERS DISPLAY GRID (OD AND OS) - HIGH DENSITY
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            RxParamTableHeader()
                            RxParamTableRow(
                                label = "Right Eye (R)",
                                sph = prescription.odSph,
                                cyl = prescription.odCyl,
                                axis = prescription.odAxis,
                                bgColor = MaterialTheme.colorScheme.surface
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            RxParamTableRow(
                                label = "Left Eye (L)",
                                sph = prescription.osSph,
                                cyl = prescription.osCyl,
                                axis = prescription.osAxis,
                                bgColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val formatAdd = prescription.odAdd?.let { if (it == 0.0) "P" else String.format(Locale.US, "%+.2f", it) } ?: "P"
                        val formatPd = prescription.odPd?.let { String.format(Locale.US, "%.0f", it) } ?: "0"

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ADD", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)
                                Text(formatAdd, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("PD", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)
                                Text("$formatPd mm", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    if (!prescription.odVasc.isNullOrBlank() || !prescription.odVscc.isNullOrBlank() ||
                        !prescription.odVabc.isNullOrBlank() || !prescription.odVaPinhole.isNullOrBlank() ||
                        !prescription.osVasc.isNullOrBlank() || !prescription.osVscc.isNullOrBlank() ||
                        !prescription.osVabc.isNullOrBlank() || !prescription.osVaPinhole.isNullOrBlank() ||
                        !prescription.binocularVabc.isNullOrBlank()
                    ) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "VISUAL ACUITY (VA) / پشکنینی هێزی بینین",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 0.5.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Right Eye (OD)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text("VASC: ${prescription.odVasc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VSCC: ${prescription.odVscc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VABC: ${prescription.odVabc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VAPinhole: ${prescription.odVaPinhole ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Left Eye (OS)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text("VASC: ${prescription.osVasc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VSCC: ${prescription.osVscc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VABC: ${prescription.osVabc ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text("VAPinhole: ${prescription.osVaPinhole ?: "-"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                                if (!prescription.binocularVabc.isNullOrBlank()) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
                                    Text("Binocular VABC (دوو چاو پێکەوە): ${prescription.binocularVabc}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }

                    val hasObjectiveData = !prescription.autorefractionReceipt.isNullOrBlank() || 
                            !prescription.keratometry.isNullOrBlank() ||
                            !prescription.odAutorefractionReceipt.isNullOrBlank() ||
                            !prescription.odKeratometry.isNullOrBlank() ||
                            !prescription.osAutorefractionReceipt.isNullOrBlank() ||
                            !prescription.osKeratometry.isNullOrBlank()

                    if (hasObjectiveData) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "OBJECTIVE REFRACTOMETRY / پشکنینی کۆمپیوتەری چاو",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 0.5.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )

                                // Unified fields (for historical records)
                                if (!prescription.autorefractionReceipt.isNullOrBlank()) {
                                    Text(
                                        text = "Autorefraction Reading / ئەنجامی کۆمپیوتەر:",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = prescription.autorefractionReceipt,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }
                                if (!prescription.keratometry.isNullOrBlank()) {
                                    Text(
                                        text = "Keratometry (K1/K2) / هێزی کەرەتا:",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = prescription.keratometry,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }

                                // Right Eye (OD) Specific
                                val hasOdObjective = !prescription.odAutorefractionReceipt.isNullOrBlank() || !prescription.odKeratometry.isNullOrBlank()
                                if (hasOdObjective) {
                                    Text(
                                        text = "Right Eye (OD) / چاوی ڕاست:",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    if (!prescription.odAutorefractionReceipt.isNullOrBlank()) {
                                        Text(
                                            text = "• Autorefraction: ${prescription.odAutorefractionReceipt}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    if (!prescription.odKeratometry.isNullOrBlank()) {
                                        Text(
                                            text = "• Keratometry (K1/K2): ${prescription.odKeratometry}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                // Left Eye (OS) Specific
                                val hasOsObjective = !prescription.osAutorefractionReceipt.isNullOrBlank() || !prescription.osKeratometry.isNullOrBlank()
                                if (hasOsObjective) {
                                    Text(
                                        text = "Left Eye (OS) / چاوی چەپ:",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    if (!prescription.osAutorefractionReceipt.isNullOrBlank()) {
                                        Text(
                                            text = "• Autorefraction: ${prescription.osAutorefractionReceipt}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    if (!prescription.osKeratometry.isNullOrBlank()) {
                                        Text(
                                            text = "• Keratometry (K1/K2): ${prescription.osKeratometry}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Spec/Order details - frames and lenses
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Frame Spec Card
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "FRAME MODEL",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = prescription.frameModel ?: "Unspecified Frame",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Lens Spec Card
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "LENS TYPE",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = prescription.lensType ?: "Unspecified Lenses",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    if (!prescription.notes.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "DIAGNOSTIC NOTES",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = prescription.notes,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    if (!prescription.photoUri.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(bottom = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "ATTACHED PHOTO / وێنەی ڕەچەتە",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                                AsyncImage(
                                    model = prescription.photoUri,
                                    contentDescription = "Prescription Photo",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 200.dp)
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RxSpecEyeRow(
    label: String,
    sph: Double?,
    cyl: Double?,
    axis: Int?,
    add: Double?,
    pd: Double?
) {
    Column {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                )
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RxParamCell("SPH", sph?.let { String.format(Locale.getDefault(), "%+.2f", it) } ?: "null")
            RxParamCell("CYL", cyl?.let { String.format(Locale.getDefault(), "%+.2f", it) } ?: "null")
            RxParamCell("AXIS", axis?.toString() ?: "null")
            RxParamCell("ADD", add?.let { String.format(Locale.getDefault(), "%+.2f", it) } ?: "null")
            RxParamCell("PD", pd?.let { String.format(Locale.getDefault(), "%.1f", it) } ?: "null")
        }
    }
}

@Composable
fun RxParamCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 9.sp, color = MaterialTheme.colorScheme.outline, fontWeight = FontWeight.SemiBold)
        Text(text = value, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MessagingActionRow(
    patient: Patient,
    prescription: Prescription,
    viewModel: OpticalViewModel,
    context: Context
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = {
                val link = viewModel.getWhatsAppLink(patient, prescription)
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("whatsapp_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("WhatsApp", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Button(
            onClick = {
                try {
                    val link = viewModel.getViberLink(patient, prescription)
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(context, "Viber not installed", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7360F2)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("viber_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Viber", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Button(
            onClick = {
                val link = viewModel.getTelegramLink(patient, prescription)
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0088CC)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("telegram_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Telegram", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PdfMessagingActionRow(
    patient: Patient,
    prescription: Prescription,
    context: Context
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = {
                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, patient, prescription)
                if (pdfUri != null) {
                    sharePdfViaApp(context, pdfUri, patient.phoneNumber, "whatsapp")
                } else {
                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("whatsapp_pdf_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("WA PDF", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Button(
            onClick = {
                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, patient, prescription)
                if (pdfUri != null) {
                    sharePdfViaApp(context, pdfUri, patient.phoneNumber, "viber")
                } else {
                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7360F2)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("viber_pdf_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Viber PDF", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Button(
            onClick = {
                val pdfUri = PdfGenerator.generateSinglePrescriptionPdf(context, patient, prescription)
                if (pdfUri != null) {
                    sharePdfViaApp(context, pdfUri, patient.phoneNumber, "telegram")
                } else {
                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0088CC)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .testTag("telegram_pdf_button_${prescription.id}"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tele PDF", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun sharePdfViaApp(context: Context, pdfUri: Uri, phoneNumber: String, appName: String) {
    val cleanPhone = phoneNumber.replace("+", "").replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    when (appName) {
        "whatsapp" -> {
            var sent = false
            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (pkg in packages) {
                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, pdfUri)
                        putExtra("jid", "$cleanPhone@s.whatsapp.net")
                        setPackage(pkg)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(intent)
                    sent = true
                    break
                } catch (e: Exception) {
                    // try next package
                }
            }
            if (!sent) {
                Toast.makeText(context, "WhatsApp is not installed on this device", Toast.LENGTH_SHORT).show()
            }
        }
        "viber" -> {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, pdfUri)
                    setPackage("com.viber.voip")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Viber is not installed on this device", Toast.LENGTH_SHORT).show()
            }
        }
        "telegram" -> {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, pdfUri)
                    setPackage("org.telegram.messenger")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Telegram is not installed on this device", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
