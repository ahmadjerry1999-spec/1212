package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Color Constants
val OpticPrimary = Color(0xFF005AC1)
val OpticOnPrimary = Color(0xFFFFFFFF)
val OpticPrimaryContainer = Color(0xFFDDE2F9)
val OpticOnPrimaryContainer = Color(0xFF001D47)

val OpticSecondary = Color(0xFF005AC1)
val OpticOnSecondary = Color(0xFFFFFFFF)
val OpticSecondaryContainer = Color(0xFFF1F3F9)
val OpticOnSecondaryContainer = Color(0xFF1A1C1E)

val OpticBackground = Color(0xFFFDFBFF)
val OpticOnBackground = Color(0xFF1A1C1E)

val OpticSurface = Color(0xFFFDFBFF)
val OpticOnSurface = Color(0xFF1A1C1E)
val OpticSurfaceVariant = Color(0xFFF3F4F9)
val OpticOnSurfaceVariant = Color(0xFF44474E)

val OpticOutline = Color(0xFF44474E)
val OpticOutlineVariant = Color(0xFFDDE2F9)

// Older colors (keeping for compatibility if compiled elsewhere)
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

