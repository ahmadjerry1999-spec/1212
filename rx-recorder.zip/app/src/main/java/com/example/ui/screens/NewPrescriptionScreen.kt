package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Prescription
import com.example.ui.viewmodel.OpticalViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewPrescriptionScreen(
    viewModel: OpticalViewModel,
    patientId: Long,
    prescriptionId: Long? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Form Field States
    var odSph by remember { mutableStateOf("0.00") }
    var odCyl by remember { mutableStateOf("0.00") }
    var odAxis by remember { mutableStateOf("") }
    var odAdd by remember { mutableStateOf("+0.00") }
    var odPd by remember { mutableStateOf("") }

    var osSph by remember { mutableStateOf("0.00") }
    var osCyl by remember { mutableStateOf("0.00") }
    var osAxis by remember { mutableStateOf("") }
    var osAdd by remember { mutableStateOf("+0.00") }
    var osPd by remember { mutableStateOf("") }

    // Visual Acuity
    var odVasc by remember { mutableStateOf("") }
    var odVscc by remember { mutableStateOf("") }
    var odVabc by remember { mutableStateOf("") }
    var odVaPinhole by remember { mutableStateOf("") }

    var osVasc by remember { mutableStateOf("") }
    var osVscc by remember { mutableStateOf("") }
    var osVabc by remember { mutableStateOf("") }
    var osVaPinhole by remember { mutableStateOf("") }

    var binocularVabc by remember { mutableStateOf("") }

    var frameModel by remember { mutableStateOf("") }
    var lensType by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var autorefractionReceipt by remember { mutableStateOf("") }
    var keratometry by remember { mutableStateOf("") }
    var odAutorefractionReceipt by remember { mutableStateOf("") }
    var odKeratometry by remember { mutableStateOf("") }
    var osAutorefractionReceipt by remember { mutableStateOf("") }
    var osKeratometry by remember { mutableStateOf("") }

    var odAxisError by remember { mutableStateOf<String?>(null) }
    var osAxisError by remember { mutableStateOf<String?>(null) }
    var odPdError by remember { mutableStateOf<String?>(null) }
    var osPdError by remember { mutableStateOf<String?>(null) }
    var odSphError by remember { mutableStateOf<String?>(null) }
    var osSphError by remember { mutableStateOf<String?>(null) }
    var odCylError by remember { mutableStateOf<String?>(null) }
    var osCylError by remember { mutableStateOf<String?>(null) }
    var odAddError by remember { mutableStateOf<String?>(null) }
    var osAddError by remember { mutableStateOf<String?>(null) }

    val prescriptions by viewModel.prescriptions.collectAsState()

    val isExtracting by viewModel.isExtracting.collectAsState()
    val extractedPrescription by viewModel.extractedPrescription.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.extractionError.collect { error ->
            Toast.makeText(context, error, Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(extractedPrescription) {
        extractedPrescription?.let { ext ->
            fun formatDouble(v: Double?): String {
                if (v == null) return "0.00"
                return if (v > 0) String.format(java.util.Locale.US, "+%.2f", v) else String.format(java.util.Locale.US, "%.2f", v)
            }
            fun formatAddDouble(v: Double?): String {
                if (v == null) return "+0.00"
                return String.format(java.util.Locale.US, "+%.2f", v)
            }

            // Populate from Right Eye / Left Eye Refraction
            ext.right_eye?.refraction?.let { r ->
                r.sphere?.let { odSph = formatDouble(it) }
                r.cylinder?.let { odCyl = formatDouble(it) }
                r.axis?.let { odAxis = it.toString() }
            } ?: ext.prescription?.right_eye_OD?.let { r ->
                r.sph?.let { odSph = formatDouble(it) }
                r.cyl?.let { odCyl = formatDouble(it) }
                r.axis?.let { odAxis = it.toString() }
                r.add?.let { odAdd = formatAddDouble(it) }
            }

            ext.left_eye?.refraction?.let { l ->
                l.sphere?.let { osSph = formatDouble(it) }
                l.cylinder?.let { osCyl = formatDouble(it) }
                l.axis?.let { osAxis = it.toString() }
            } ?: ext.prescription?.left_eye_OS?.let { l ->
                l.sph?.let { osSph = formatDouble(it) }
                l.cyl?.let { osCyl = formatDouble(it) }
                l.axis?.let { osAxis = it.toString() }
                l.add?.let { osAdd = formatAddDouble(it) }
            }

            // Populate PD
            ext.prescription?.pd?.let {
                val pdStr = String.format(java.util.Locale.US, "%.0f", it)
                odPd = pdStr
                osPd = pdStr
            }

            // Populate choices
            ext.choices?.frame?.let { if (it.isNotBlank()) frameModel = it }
            ext.choices?.lenses?.let { if (it.isNotBlank()) lensType = it }

            // Populate Keratometry
            ext.right_eye?.keratometry?.let { k ->
                val k1Str = k.k1?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                val k1AxisStr = k.k1_axis?.let { String.format(java.util.Locale.US, "%03d", it) } ?: ""
                val k2Str = k.k2?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                val k2AxisStr = k.k2_axis?.let { String.format(java.util.Locale.US, "%03d", it) } ?: ""
                val deltaStr = k.delta?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                
                if (k1Str.isNotEmpty() && k2Str.isNotEmpty()) {
                    odKeratometry = "$k1Str @ $k1AxisStr / $k2Str @ $k2AxisStr (Δ $deltaStr)"
                }
            } ?: ext.od_keratometry?.let { odKeratometry = it }

            ext.left_eye?.keratometry?.let { k ->
                val k1Str = k.k1?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                val k1AxisStr = k.k1_axis?.let { String.format(java.util.Locale.US, "%03d", it) } ?: ""
                val k2Str = k.k2?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                val k2AxisStr = k.k2_axis?.let { String.format(java.util.Locale.US, "%03d", it) } ?: ""
                val deltaStr = k.delta?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                
                if (k1Str.isNotEmpty() && k2Str.isNotEmpty()) {
                    osKeratometry = "$k1Str @ $k1AxisStr / $k2Str @ $k2AxisStr (Δ $deltaStr)"
                }
            } ?: ext.os_keratometry?.let { osKeratometry = it }

            // Receipts/Slips
            ext.od_autorefraction_receipt?.let { if (it.isNotBlank()) odAutorefractionReceipt = it }
            ext.os_autorefraction_receipt?.let { if (it.isNotBlank()) osAutorefractionReceipt = it }
            ext.autorefraction_receipt?.let { if (it.isNotBlank()) autorefractionReceipt = it }
            ext.keratometry?.let { if (it.isNotBlank()) keratometry = it }

            Toast.makeText(context, "Prescription successfully filled from Photo!", Toast.LENGTH_SHORT).show()
            viewModel.clearExtractedPrescription()
        }
    }

    var currentPrescriptionId by remember { mutableStateOf(prescriptionId) }
    var isInitialized by remember { mutableStateOf(prescriptionId == null) }

    // Reference Photo UI States
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cameraTempPhotoUri by remember { mutableStateOf<Uri?>(null) }

    // Auto-populate when editing an existing prescription
    LaunchedEffect(currentPrescriptionId, prescriptions) {
        if (currentPrescriptionId != null && prescriptions.isNotEmpty() && !isInitialized) {
            val existing = prescriptions.find { it.id == currentPrescriptionId }
            existing?.let { rx ->
                fun formatDouble(v: Double?): String {
                    if (v == null) return ""
                    return if (v > 0) String.format(java.util.Locale.US, "+%.2f", v) else String.format(java.util.Locale.US, "%.2f", v)
                }
                fun formatAddDouble(v: Double?): String {
                    if (v == null) return "+0.00"
                    return String.format(java.util.Locale.US, "+%.2f", v)
                }
                odSph = if (rx.odSph == null) "0.00" else formatDouble(rx.odSph)
                odCyl = if (rx.odCyl == null) "0.00" else formatDouble(rx.odCyl)
                odAxis = rx.odAxis?.toString() ?: ""
                odAdd = formatAddDouble(rx.odAdd)
                odPd = rx.odPd?.let { String.format(java.util.Locale.US, "%.0f", it) } ?: ""
                
                osSph = if (rx.osSph == null) "0.00" else formatDouble(rx.osSph)
                osCyl = if (rx.osCyl == null) "0.00" else formatDouble(rx.osCyl)
                osAxis = rx.osAxis?.toString() ?: ""
                osAdd = formatAddDouble(rx.osAdd)
                osPd = rx.osPd?.let { String.format(java.util.Locale.US, "%.0f", it) } ?: ""

                odVasc = rx.odVasc ?: ""
                odVscc = rx.odVscc ?: ""
                odVabc = rx.odVabc ?: ""
                odVaPinhole = rx.odVaPinhole ?: ""

                osVasc = rx.osVasc ?: ""
                osVscc = rx.osVscc ?: ""
                osVabc = rx.osVabc ?: ""
                osVaPinhole = rx.osVaPinhole ?: ""

                binocularVabc = rx.binocularVabc ?: ""
                
                frameModel = rx.frameModel ?: ""
                lensType = rx.lensType ?: ""
                notes = rx.notes ?: ""
                autorefractionReceipt = rx.autorefractionReceipt ?: ""
                keratometry = rx.keratometry ?: ""
                odAutorefractionReceipt = rx.odAutorefractionReceipt ?: ""
                odKeratometry = rx.odKeratometry ?: ""
                osAutorefractionReceipt = rx.osAutorefractionReceipt ?: ""
                osKeratometry = rx.osKeratometry ?: ""
                selectedImageUri = rx.photoUri?.let { Uri.parse(it) }

                isInitialized = true
            }
        }
    }

    val autoSavePrefs = remember {
        context.getSharedPreferences("ahmed_optical_prefs", android.content.Context.MODE_PRIVATE)
    }
    val autoSaveEnabled = remember {
        autoSavePrefs.getBoolean("pref_auto_save", true)
    }
    var lastSavedTime by remember { mutableStateOf<String?>(null) }

    val isAnyFieldFilled = odAxis.isNotEmpty() || odPd.isNotEmpty() || 
        osAxis.isNotEmpty() || osPd.isNotEmpty() || 
        odVasc.isNotEmpty() || odVscc.isNotEmpty() || odVabc.isNotEmpty() || odVaPinhole.isNotEmpty() ||
        osVasc.isNotEmpty() || osVscc.isNotEmpty() || osVabc.isNotEmpty() || osVaPinhole.isNotEmpty() ||
        binocularVabc.isNotEmpty() || frameModel.isNotEmpty() || lensType.isNotEmpty() || notes.isNotEmpty() ||
        autorefractionReceipt.isNotEmpty() || keratometry.isNotEmpty() ||
        odAutorefractionReceipt.isNotEmpty() || odKeratometry.isNotEmpty() ||
        osAutorefractionReceipt.isNotEmpty() || osKeratometry.isNotEmpty() ||
        selectedImageUri != null

    if (autoSaveEnabled && isInitialized) {
        LaunchedEffect(
            odSph, odCyl, odAxis, odAdd, odPd,
            osSph, osCyl, osAxis, osAdd, osPd,
            odVasc, odVscc, odVabc, odVaPinhole,
            osVasc, osVscc, osVabc, osVaPinhole,
            binocularVabc, frameModel, lensType, notes,
            autorefractionReceipt, keratometry,
            odAutorefractionReceipt, odKeratometry,
            osAutorefractionReceipt, osKeratometry,
            selectedImageUri
        ) {
            // Debounce for 3 seconds of inactivity
            kotlinx.coroutines.delay(3000)

            val shouldSave = currentPrescriptionId != null || isAnyFieldFilled

            if (shouldSave) {
                val parseDouble = { s: String -> s.toDoubleOrNull() }
                val parseInt = { s: String -> s.toIntOrNull() }

                val prescription = Prescription(
                    id = currentPrescriptionId ?: 0,
                    patientId = patientId,
                    odSph = parseDouble(odSph),
                    odCyl = parseDouble(odCyl),
                    odAxis = parseInt(odAxis)?.coerceIn(0, 180),
                    odAdd = parseDouble(odAdd),
                    odPd = parseDouble(odPd),
                    osSph = parseDouble(osSph),
                    osCyl = parseDouble(osCyl),
                    osAxis = parseInt(osAxis)?.coerceIn(0, 180),
                    osAdd = parseDouble(osAdd),
                    osPd = parseDouble(osPd),
                    odVasc = odVasc.takeIf { it.isNotBlank() },
                    odVscc = odVscc.takeIf { it.isNotBlank() },
                    odVabc = odVabc.takeIf { it.isNotBlank() },
                    odVaPinhole = odVaPinhole.takeIf { it.isNotBlank() },
                    osVasc = osVasc.takeIf { it.isNotBlank() },
                    osVscc = osVscc.takeIf { it.isNotBlank() },
                    osVabc = osVabc.takeIf { it.isNotBlank() },
                    osVaPinhole = osVaPinhole.takeIf { it.isNotBlank() },
                    binocularVabc = binocularVabc.takeIf { it.isNotBlank() },
                    frameModel = frameModel.takeIf { it.isNotBlank() },
                    lensType = lensType.takeIf { it.isNotBlank() },
                    notes = notes.takeIf { it.isNotBlank() },
                    autorefractionReceipt = autorefractionReceipt.takeIf { it.isNotBlank() },
                    keratometry = keratometry.takeIf { it.isNotBlank() },
                    odAutorefractionReceipt = odAutorefractionReceipt.takeIf { it.isNotBlank() },
                    odKeratometry = odKeratometry.takeIf { it.isNotBlank() },
                    osAutorefractionReceipt = osAutorefractionReceipt.takeIf { it.isNotBlank() },
                    osKeratometry = osKeratometry.takeIf { it.isNotBlank() },
                    photoUri = selectedImageUri?.toString()
                )

                viewModel.addPrescription(prescription) { savedId ->
                    if (currentPrescriptionId == null) {
                        currentPrescriptionId = savedId
                    }
                    val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    lastSavedTime = sdf.format(java.util.Date())
                }
            }
        }
    }

    // Handle Image picking
    val lazyImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
        if (uri != null) {
            try {
                selectedBitmap = if (Build.VERSION.SDK_INT < 28) {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                } else {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            val uri = cameraTempPhotoUri
            if (uri != null) {
                selectedImageUri = uri
                try {
                    selectedBitmap = if (Build.VERSION.SDK_INT < 28) {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                    } else {
                        val source = ImageDecoder.createSource(context.contentResolver, uri)
                        ImageDecoder.decodeBitmap(source)
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Failed to load camera photo", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun createTempImageUri(ctx: Context): Uri? {
        return try {
            val file = java.io.File(ctx.cacheDir, "temp_camera.jpg")
            if (file.exists()) {
                file.delete()
            }
            file.createNewFile()
            androidx.core.content.FileProvider.getUriForFile(
                ctx,
                "${ctx.packageName}.fileprovider",
                file
            )
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            null
        }
    }



    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = if (prescriptionId == null) "New Rx & Order" else "Edit Rx & Order", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        if (lastSavedTime != null) {
                            Text(
                                text = "Draft auto-saved at $lastSavedTime",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        } else if (autoSaveEnabled) {
                            Text(
                                text = "Auto-save active",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button_new_rx")) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Prescription Photo Attachment - HIGH DENSITY STYLE
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            tint = MaterialTheme.colorScheme.primary,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Prescription Photo / ڕەسمی ڕەچەتە",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = "Snap a quick photo of the patient's prescription slip or upload one to keep as a visual reference.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Image Thumbnail displaying
                    if (selectedImageUri != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AsyncImage(
                                model = selectedImageUri,
                                contentDescription = "Attached Prescription Photo",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 240.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Fit
                            )
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "✓ Reference Photo Loaded",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                TextButton(
                                    onClick = {
                                        selectedImageUri = null
                                        selectedBitmap = null
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Photo",
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "Delete Photo / سڕینەوە",
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Button(
                                onClick = {
                                    val customApiKey = autoSavePrefs.getString("gemini_api_key", "") ?: ""
                                    viewModel.runAiExtraction(
                                        text = null,
                                        image = selectedBitmap,
                                        customApiKey = customApiKey.takeIf { it.isNotBlank() }
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_extract_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                enabled = !isExtracting
                            ) {
                                if (isExtracting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Analyzing with Gemini... / شیکردنەوە بە ژیری دەستکرد", fontSize = 12.sp)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Extract with AI / دەرهێنان بە ژیری دەستکرد", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val uri = createTempImageUri(context)
                                if (uri != null) {
                                    cameraTempPhotoUri = uri
                                    cameraLauncher.launch(uri)
                                } else {
                                    Toast.makeText(context, "Failed to initialize camera", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("camera_scan_button")
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Take Photo", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { lazyImagePicker.launch("image/*") },
                            modifier = Modifier.weight(1f).testTag("upload_scan_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Upload Photo", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Prescription Parameter Header
            Text(
                text = "Prescription Values",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )

            // Right Eye (OD) Form Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Right Eye (OD)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StepperOpticField(
                            value = odSph,
                            onValueChange = {
                                odSph = it
                                odSphError = null
                            },
                            label = "SPH",
                            min = -20.0,
                            max = 20.0,
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_sph",
                            errorText = odSphError
                        )
                        
                        StepperOpticField(
                            value = odCyl,
                            onValueChange = {
                                odCyl = it
                                odCylError = null
                            },
                            label = "CYL",
                            min = -9.0,
                            max = 0.0,
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_cyl",
                            errorText = odCylError
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FormTextField(
                            value = odAxis,
                            onValueChange = { newValue ->
                                val digitsOnly = newValue.filter { it.isDigit() }
                                val parsed = digitsOnly.toIntOrNull()
                                if (parsed == null) {
                                    odAxis = digitsOnly
                                } else if (parsed > 180) {
                                    odAxis = "180"
                                } else {
                                    odAxis = digitsOnly
                                }
                                odAxisError = null
                            },
                            label = "AXIS (0 to 180)",
                            modifier = Modifier.weight(1f),
                            isInteger = true,
                            errorText = odAxisError,
                            testTag = "rx_od_axis"
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "Visual Acuity (OD)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualAcuityDropdown(
                            value = odVasc,
                            onValueChange = { odVasc = it },
                            label = "VASC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_vasc"
                        )
                        VisualAcuityDropdown(
                            value = odVscc,
                            onValueChange = { odVscc = it },
                            label = "VSCC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_vscc"
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualAcuityDropdown(
                            value = odVabc,
                            onValueChange = { odVabc = it },
                            label = "VABC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_vabc"
                        )
                        VisualAcuityDropdown(
                            value = odVaPinhole,
                            onValueChange = { odVaPinhole = it },
                            label = "VAPinhole",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_od_vapinhole"
                        )
                    }
                }
            }

            // Left Eye (OS) Form Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Left Eye (OS)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StepperOpticField(
                            value = osSph,
                            onValueChange = {
                                osSph = it
                                osSphError = null
                            },
                            label = "SPH",
                            min = -20.0,
                            max = 20.0,
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_sph",
                            errorText = osSphError
                        )
                        
                        StepperOpticField(
                            value = osCyl,
                            onValueChange = {
                                osCyl = it
                                osCylError = null
                            },
                            label = "CYL",
                            min = -9.0,
                            max = 0.0,
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_cyl",
                            errorText = osCylError
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FormTextField(
                            value = osAxis,
                            onValueChange = { newValue ->
                                val digitsOnly = newValue.filter { it.isDigit() }
                                val parsed = digitsOnly.toIntOrNull()
                                if (parsed == null) {
                                    osAxis = digitsOnly
                                } else if (parsed > 180) {
                                    osAxis = "180"
                                } else {
                                    osAxis = digitsOnly
                                }
                                osAxisError = null
                            },
                            label = "AXIS (0 to 180)",
                            modifier = Modifier.weight(1f),
                            isInteger = true,
                            errorText = osAxisError,
                            testTag = "rx_os_axis"
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "Visual Acuity (OS)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualAcuityDropdown(
                            value = osVasc,
                            onValueChange = { osVasc = it },
                            label = "VASC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_vasc"
                        )
                        VisualAcuityDropdown(
                            value = osVscc,
                            onValueChange = { osVscc = it },
                            label = "VSCC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_vscc"
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualAcuityDropdown(
                            value = osVabc,
                            onValueChange = { osVabc = it },
                            label = "VABC",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_vabc"
                        )
                        VisualAcuityDropdown(
                            value = osVaPinhole,
                            onValueChange = { osVaPinhole = it },
                            label = "VAPinhole",
                            modifier = Modifier.weight(1f),
                            testTag = "rx_os_vapinhole"
                        )
                    }
                }
            }

            // Shared Prescription Parameters (Binocular) Form Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Shared Parameters",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    StepperAddPowerField(
                        value = odAdd,
                        onValueChange = {
                            odAdd = it
                            osAdd = it
                            odAddError = null
                            osAddError = null
                        },
                        label = "ADD (Near Addition)",
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "rx_od_add",
                        errorText = odAddError
                    )

                    FormTextField(
                        value = odPd,
                        onValueChange = {
                            odPd = it
                            osPd = it
                            odPdError = null
                            osPdError = null
                        },
                        label = "PD (Pupillary Distance)",
                        modifier = Modifier.fillMaxWidth(),
                        errorText = odPdError,
                        testTag = "rx_od_pd"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "Visual Acuity (Binocular / دوو چاو پێکەوە)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualAcuityDropdown(
                            value = binocularVabc,
                            onValueChange = { binocularVabc = it },
                            label = "VABC (Binocular)",
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "rx_binocular_vabc"
                        )
                    }
                }
            }

            // Objective Refraction Card (Autorefraction & Keratometry)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Objective Refraction / کۆمپیوتەری چاو",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Right Eye (OD)
                    Text(
                        text = "Right Eye (OD) / چاوی ڕاست",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = odAutorefractionReceipt,
                            onValueChange = { odAutorefractionReceipt = it },
                            label = { Text("OD Autorefraction", fontSize = 11.sp) },
                            placeholder = { Text("e.g. SPH/CYL Slip", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.weight(1f).testTag("rx_od_autorefraction_receipt")
                        )
                        OutlinedTextField(
                            value = odKeratometry,
                            onValueChange = { odKeratometry = it },
                            label = { Text("OD Keratometry", fontSize = 11.sp) },
                            placeholder = { Text("K1/K2 values", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.weight(1f).testTag("rx_od_keratometry")
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))

                    // Left Eye (OS)
                    Text(
                        text = "Left Eye (OS) / چاوی چەپ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = osAutorefractionReceipt,
                            onValueChange = { osAutorefractionReceipt = it },
                            label = { Text("OS Autorefraction", fontSize = 11.sp) },
                            placeholder = { Text("e.g. SPH/CYL Slip", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.weight(1f).testTag("rx_os_autorefraction_receipt")
                        )
                        OutlinedTextField(
                            value = osKeratometry,
                            onValueChange = { osKeratometry = it },
                            label = { Text("OS Keratometry", fontSize = 11.sp) },
                            placeholder = { Text("K1/K2 values", fontSize = 11.sp) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            modifier = Modifier.weight(1f).testTag("rx_os_keratometry")
                        )
                    }
                }
            }

            // Order Section & Extras
            Text(
                text = "Order Prescription Details",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = frameModel,
                onValueChange = { frameModel = it },
                label = { Text("Frame Model Selection") },
                placeholder = { Text("e.g. Gucci G8239, Ray-Ban Clubmaster") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rx_frame")
            )

            OutlinedTextField(
                value = lensType,
                onValueChange = { lensType = it },
                label = { Text("Lens Type Specification") },
                placeholder = { Text("e.g. Blue-Cut Transition, Anti-Reflective Crizal") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rx_lens")
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Custom Notes or Instructions") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rx_notes")
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    // Assemble & Save Prescription
                    var isValid = true
                    
                    // Reset error states
                    odSphError = null
                    osSphError = null
                    odCylError = null
                    osCylError = null
                    odAxisError = null
                    osAxisError = null
                    odPdError = null
                    osPdError = null

                    // SPH range validation
                    val sphOd = odSph.toDoubleOrNull()
                    if (odSph.isNotBlank()) {
                        if (sphOd == null) {
                            odSphError = "Invalid number"
                            isValid = false
                        } else if (sphOd < -20.0 || sphOd > 20.0) {
                            odSphError = "Range: -20.00 to +20.00"
                            isValid = false
                        }
                    }

                    val sphOs = osSph.toDoubleOrNull()
                    if (osSph.isNotBlank()) {
                        if (sphOs == null) {
                            osSphError = "Invalid number"
                            isValid = false
                        } else if (sphOs < -20.0 || sphOs > 20.0) {
                            osSphError = "Range: -20.00 to +20.00"
                            isValid = false
                        }
                    }

                    // CYL range validation
                    val cylOd = odCyl.toDoubleOrNull()
                    if (odCyl.isNotBlank()) {
                        if (cylOd == null) {
                            odCylError = "Invalid number"
                            isValid = false
                        } else if (cylOd < -9.0 || cylOd > 0.0) {
                            odCylError = "Range: -9.00 to 0.00"
                            isValid = false
                        }
                    }

                    val cylOs = osCyl.toDoubleOrNull()
                    if (osCyl.isNotBlank()) {
                        if (cylOs == null) {
                            osCylError = "Invalid number"
                            isValid = false
                        } else if (cylOs < -9.0 || cylOs > 0.0) {
                            osCylError = "Range: -9.00 to 0.00"
                            isValid = false
                        }
                    }

                    // ADD range validation
                    val addOd = odAdd.filter { it.isDigit() || it == '.' || it == '-' || it == '+' }.toDoubleOrNull()
                    if (odAdd.isNotBlank()) {
                        if (addOd == null) {
                            odAddError = "Invalid number"
                            isValid = false
                        } else if (addOd < 0.0 || addOd > 4.0) {
                            odAddError = "Range: 0.00 to +4.00"
                            isValid = false
                        }
                    }

                    val addOs = osAdd.filter { it.isDigit() || it == '.' || it == '-' || it == '+' }.toDoubleOrNull()
                    if (osAdd.isNotBlank()) {
                        if (addOs == null) {
                            osAddError = "Invalid number"
                            isValid = false
                        } else if (addOs < 0.0 || addOs > 4.0) {
                            osAddError = "Range: 0.00 to +4.00"
                            isValid = false
                        }
                    }

                    // Validate Axis
                    val axisOd = odAxis.toIntOrNull()
                    if (odAxis.isNotBlank()) {
                        if (axisOd == null) {
                            odAxisError = "Must be an integer"
                            isValid = false
                        } else if (axisOd < 0 || axisOd > 180) {
                            odAxisError = "Must be 0 to 180"
                            isValid = false
                        }
                    }

                    val axisOs = osAxis.toIntOrNull()
                    if (osAxis.isNotBlank()) {
                        if (axisOs == null) {
                            osAxisError = "Must be an integer"
                            isValid = false
                        } else if (axisOs < 0 || axisOs > 180) {
                            osAxisError = "Must be 0 to 180"
                            isValid = false
                        }
                    }

                    // Validate PD
                    val pdOd = odPd.toDoubleOrNull()
                    if (odPd.isNotBlank()) {
                        if (pdOd == null) {
                            odPdError = "Invalid number"
                            isValid = false
                        } else if (pdOd < 20.0 || pdOd > 75.0) {
                            odPdError = "Range: 20 to 75"
                            isValid = false
                        }
                    }

                    val pdOs = osPd.toDoubleOrNull()
                    if (osPd.isNotBlank()) {
                        if (pdOs == null) {
                            osPdError = "Invalid number"
                            isValid = false
                        } else if (pdOs < 20.0 || pdOs > 75.0) {
                            osPdError = "Range: 20 to 75"
                            isValid = false
                        }
                    }

                    if (!isValid) {
                        Toast.makeText(context, "Please correct the prescription errors first.", Toast.LENGTH_SHORT).show()
                    } else {
                        // All valid, snap SPH and CYL values to nearest 0.25 on save!
                        val finalOdSph = if (odSph.isNotBlank()) (Math.round((sphOd ?: 0.0) * 4.0) / 4.0) else null
                        val finalOdCyl = if (odCyl.isNotBlank()) (Math.round((cylOd ?: 0.0) * 4.0) / 4.0) else null
                        val finalOsSph = if (osSph.isNotBlank()) (Math.round((sphOs ?: 0.0) * 4.0) / 4.0) else null
                        val finalOsCyl = if (osCyl.isNotBlank()) (Math.round((cylOs ?: 0.0) * 4.0) / 4.0) else null

                        val finalOdAdd = if (odAdd.isNotBlank()) (Math.round((addOd ?: 0.0) * 4.0) / 4.0) else null
                        val finalOsAdd = if (osAdd.isNotBlank()) (Math.round((addOs ?: 0.0) * 4.0) / 4.0) else null

                        val existing = if (currentPrescriptionId != null) prescriptions.find { it.id == currentPrescriptionId } else null
                        val finalDateMillis = existing?.dateMillis ?: System.currentTimeMillis()

                        val prescription = Prescription(
                            id = currentPrescriptionId ?: 0,
                            patientId = patientId,
                            dateMillis = finalDateMillis,
                            odSph = finalOdSph,
                            odCyl = finalOdCyl,
                            odAxis = axisOd,
                            odAdd = finalOdAdd,
                            odPd = pdOd,
                            osSph = finalOsSph,
                            osCyl = finalOsCyl,
                            osAxis = axisOs,
                            osAdd = finalOsAdd,
                            osPd = pdOs,
                            odVasc = odVasc.takeIf { it.isNotBlank() },
                            odVscc = odVscc.takeIf { it.isNotBlank() },
                            odVabc = odVabc.takeIf { it.isNotBlank() },
                            odVaPinhole = odVaPinhole.takeIf { it.isNotBlank() },
                            osVasc = osVasc.takeIf { it.isNotBlank() },
                            osVscc = osVscc.takeIf { it.isNotBlank() },
                            osVabc = osVabc.takeIf { it.isNotBlank() },
                            osVaPinhole = osVaPinhole.takeIf { it.isNotBlank() },
                            binocularVabc = binocularVabc.takeIf { it.isNotBlank() },
                            frameModel = frameModel.takeIf { it.isNotBlank() },
                            lensType = lensType.takeIf { it.isNotBlank() },
                            notes = notes.takeIf { it.isNotBlank() },
                            autorefractionReceipt = autorefractionReceipt.takeIf { it.isNotBlank() },
                            keratometry = keratometry.takeIf { it.isNotBlank() },
                            odAutorefractionReceipt = odAutorefractionReceipt.takeIf { it.isNotBlank() },
                            odKeratometry = odKeratometry.takeIf { it.isNotBlank() },
                            osAutorefractionReceipt = osAutorefractionReceipt.takeIf { it.isNotBlank() },
                            osKeratometry = osKeratometry.takeIf { it.isNotBlank() },
                            photoUri = selectedImageUri?.toString()
                        )

                        viewModel.addPrescription(prescription) { _ ->
                            Toast.makeText(context, "Saved Prescription Entry", Toast.LENGTH_SHORT).show()
                            onNavigateBack()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_prescription_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Prescription & Order Record", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun FormTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isInteger: Boolean = false,
    errorText: String? = null,
    testTag: String = ""
) {
    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = { newValue ->
                val filtered = if (isInteger) {
                    newValue.filter { it.isDigit() }
                } else {
                    newValue.filter { it.isDigit() || it == '.' || it == '-' || it == '+' }
                }
                onValueChange(filtered)
            },
            label = { Text(label) },
            singleLine = true,
            isError = errorText != null,
            modifier = Modifier.fillMaxWidth().testTag(testTag),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = KeyboardType.Number
            )
        )
        if (errorText != null) {
            Text(
                text = errorText,
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
            )
        }
    }
}

@Composable
fun StepperOpticField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    min: Double,
    max: Double,
    modifier: Modifier = Modifier,
    testTag: String = "",
    errorText: String? = null
) {
    val currentValue = value.toDoubleOrNull() ?: 0.0

    fun formatDoubleValue(v: Double): String {
        return if (v > 0) {
            String.format(java.util.Locale.US, "+%.2f", v)
        } else {
            String.format(java.util.Locale.US, "%.2f", v)
        }
    }

    fun snapToNearestPoint25(v: Double): Double {
        val snapped = Math.round(v * 4.0) / 4.0
        return snapped.coerceIn(min, max)
    }

    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = { input ->
                val filtered = input.filter { it.isDigit() || it == '.' || it == '-' || it == '+' }
                onValueChange(filtered)
            },
            singleLine = true,
            isError = errorText != null,
            modifier = Modifier.fillMaxWidth().testTag(testTag),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = KeyboardType.Number
            ),
            leadingIcon = {
                IconButton(
                    onClick = {
                        val newValue = snapToNearestPoint25(currentValue - 0.25)
                        onValueChange(formatDoubleValue(newValue))
                    },
                    modifier = Modifier.size(36.dp).testTag("${testTag}_minus")
                ) {
                    Text("-", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            },
            trailingIcon = {
                IconButton(
                    onClick = {
                        val newValue = snapToNearestPoint25(currentValue + 0.25)
                        onValueChange(formatDoubleValue(newValue))
                    },
                    modifier = Modifier.size(36.dp).testTag("${testTag}_plus")
                ) {
                    Text("+", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            },
            textStyle = LocalTextStyle.current.copy(
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontWeight = FontWeight.SemiBold
            )
        )
        if (errorText != null) {
            Text(
                text = errorText,
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
            )
        }
    }
}

@Composable
fun StepperAddPowerField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = "",
    errorText: String? = null
) {
    val currentValue = value.filter { it.isDigit() || it == '.' || it == '-' || it == '+' }.toDoubleOrNull() ?: 0.0

    fun formatAddValue(v: Double): String {
        return String.format(java.util.Locale.US, "+%.2f", v)
    }

    fun snapToNearestPoint25(v: Double): Double {
        val snapped = Math.round(v * 4.0) / 4.0
        return snapped.coerceIn(0.0, 4.0)
    }

    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = { input ->
                val filtered = input.filter { it.isDigit() || it == '.' || it == '+' || it == '-' }
                onValueChange(filtered)
            },
            singleLine = true,
            isError = errorText != null,
            modifier = Modifier.fillMaxWidth().testTag(testTag),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = KeyboardType.Number
            ),
            leadingIcon = {
                IconButton(
                    onClick = {
                        val newValue = snapToNearestPoint25(currentValue - 0.25)
                        onValueChange(formatAddValue(newValue))
                    },
                    modifier = Modifier.size(36.dp).testTag("${testTag}_minus")
                ) {
                    Text("-", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            },
            trailingIcon = {
                IconButton(
                    onClick = {
                        val newValue = snapToNearestPoint25(currentValue + 0.25)
                        onValueChange(formatAddValue(newValue))
                    },
                    modifier = Modifier.size(36.dp).testTag("${testTag}_plus")
                ) {
                    Text("+", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
            },
            textStyle = LocalTextStyle.current.copy(
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontWeight = FontWeight.SemiBold
            )
        )
        if (errorText != null) {
            Text(
                text = errorText,
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisualAcuityDropdown(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val options = remember {
        listOf(
            "", // The blank option
            "0.0", "0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4", "1.5",
            "CF1", "CF2", "CF3", "HM", "NLP"
        )
    }
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = if (value.isEmpty()) "-- Select VA --" else value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, fontSize = 11.sp) },
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .testTag(testTag)
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                val displayLabel = if (option.isEmpty()) "-- Select VA --" else option
                DropdownMenuItem(
                    text = { Text(displayLabel, fontSize = 11.sp) },
                    onClick = {
                        onValueChange(option)
                        expanded = false
                    },
                    modifier = Modifier.testTag("${testTag}_option_${if (option.isEmpty()) "empty" else option}")
                )
            }
        }
    }
}

