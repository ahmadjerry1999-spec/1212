package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.ExtractedPrescription
import com.example.data.api.GeminiClient
import com.example.data.model.Patient
import com.example.data.model.Prescription
import com.example.data.repository.OpticalRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.net.URLEncoder

class OpticalViewModel(private val repository: OpticalRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val patients: StateFlow<List<Patient>> = _searchQuery
        .flatMapLatest { query ->
            repository.searchPatients(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPatients: StateFlow<List<Patient>> = repository.allPatients
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPrescriptions: StateFlow<List<Prescription>> = repository.allPrescriptions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedPatientId = MutableStateFlow<Long?>(null)
    val selectedPatientId = _selectedPatientId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedPatient: StateFlow<Patient?> = _selectedPatientId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else repository.getPatientById(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val prescriptions: StateFlow<List<Prescription>> = _selectedPatientId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getPrescriptionsForPatient(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // AI Extraction State
    private val _isExtracting = MutableStateFlow(false)
    val isExtracting = _isExtracting.asStateFlow()

    private val _extractedPrescription = MutableStateFlow<ExtractedPrescription?>(null)
    val extractedPrescription = _extractedPrescription.asStateFlow()

    private val _extractionError = MutableSharedFlow<String>()
    val extractionError = _extractionError.asSharedFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectPatient(patientId: Long?) {
        _selectedPatientId.value = patientId
    }

    fun addPatient(context: android.content.Context, id: Long = 0, name: String, phone: String, dob: String, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val patient = Patient(id = id, fullName = name, phoneNumber = formatPhoneNumber(phone), dateOfBirth = dob)
            val newId = repository.insertPatient(patient)
            onComplete(newId)

            try {
                val count = repository.getPatientCount()
                if (count > 0 && count % 20 == 0) {
                    exportToJson { success, jsonText ->
                        if (success) {
                            val lm = com.example.util.LocalBackupManager(context)
                            lm.saveSilentBackup(jsonText)
                            android.widget.Toast.makeText(context, "Silent auto-backup: $count patients saved.", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            android.util.Log.e("AutoBackup", "Silent auto-backup failed: $jsonText")
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deletePatient(patient: Patient) {
        viewModelScope.launch {
            repository.deletePatient(patient)
            if (_selectedPatientId.value == patient.id) {
                _selectedPatientId.value = null
            }
        }
    }

    fun addPrescription(prescription: Prescription, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val insertedId = repository.insertPrescription(prescription)
            onComplete(insertedId)
        }
    }

    fun importCsv(context: Context, uri: Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream == null) {
                    onResult(false, "Could not open file")
                    return@launch
                }
                val reader = inputStream.bufferedReader()
                val lines = reader.readLines()
                inputStream.close()
                if (lines.isEmpty()) {
                    onResult(false, "File is empty")
                    return@launch
                }

                // parse helper that respects quotes
                fun parseCsvLine(line: String): List<String> {
                    val result = mutableListOf<String>()
                    var currentStr = java.lang.StringBuilder()
                    var inQuotes = false
                    var i = 0
                    while (i < line.length) {
                        val c = line[i]
                        if (c == '"') {
                            if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                                currentStr.append('"')
                                i++
                            } else {
                                inQuotes = !inQuotes
                            }
                        } else if (c == ',' && !inQuotes) {
                            result.add(currentStr.toString().trim())
                            currentStr = java.lang.StringBuilder()
                        } else {
                            currentStr.append(c)
                        }
                        i++
                    }
                    result.add(currentStr.toString().trim())
                    return result
                }

                val rows = lines.drop(1)
                
                var importedPatients = 0
                var importedPrescriptions = 0

                val existingPatients = allPatients.value

                for (rowLine in rows) {
                    if (rowLine.isBlank()) continue
                    val columns = parseCsvLine(rowLine)
                    if (columns.size < 3) continue

                    val name = columns.getOrNull(0) ?: ""
                    val phone = columns.getOrNull(1) ?: ""
                    val dob = columns.getOrNull(2) ?: ""

                    if (name.isBlank()) continue

                    // Check if patient already exists (search by phone or name)
                    val formattedPhone = formatPhoneNumber(phone)
                    var patientId = existingPatients.find { 
                        it.fullName.equals(name, ignoreCase = true) && 
                        formatPhoneNumber(it.phoneNumber) == formattedPhone 
                    }?.id

                    if (patientId == null) {
                        val p = Patient(fullName = name, phoneNumber = formattedPhone, dateOfBirth = dob)
                        patientId = repository.insertPatient(p)
                        importedPatients++
                    }

                    // Extract prescription details
                    val parseDouble = { s: String? ->
                        if (s == null || s == "P" || s.isBlank()) null else s.toDoubleOrNull()
                    }
                    val parseInt = { s: String? ->
                        if (s == null || s.isBlank()) null else s.toIntOrNull()
                    }

                    val odSph = parseDouble(columns.getOrNull(3))
                    val odCyl = parseDouble(columns.getOrNull(4))
                    val odAxis = parseInt(columns.getOrNull(5))
                    val osSph = parseDouble(columns.getOrNull(6))
                    val osCyl = parseDouble(columns.getOrNull(7))
                    val osAxis = parseInt(columns.getOrNull(8))
                    val odAdd = parseDouble(columns.getOrNull(9))
                    val odPd = parseDouble(columns.getOrNull(10))

                    val odVasc = columns.getOrNull(11)?.takeIf { it.isNotBlank() }
                    val odVscc = columns.getOrNull(12)?.takeIf { it.isNotBlank() }
                    val odVabc = columns.getOrNull(13)?.takeIf { it.isNotBlank() }
                    val odVaPinhole = columns.getOrNull(14)?.takeIf { it.isNotBlank() }

                    val osVasc = columns.getOrNull(15)?.takeIf { it.isNotBlank() }
                    val osVscc = columns.getOrNull(16)?.takeIf { it.isNotBlank() }
                    val osVabc = columns.getOrNull(17)?.takeIf { it.isNotBlank() }
                    val osVaPinhole = columns.getOrNull(18)?.takeIf { it.isNotBlank() }

                    val binocularVabc = columns.getOrNull(19)?.takeIf { it.isNotBlank() }
                    val autorefractionReceipt = columns.getOrNull(20)?.takeIf { it.isNotBlank() }
                    val keratometry = columns.getOrNull(21)?.takeIf { it.isNotBlank() }

                    val odAutorefractionReceipt = columns.getOrNull(22)?.takeIf { it.isNotBlank() }
                    val odKeratometry = columns.getOrNull(23)?.takeIf { it.isNotBlank() }
                    val osAutorefractionReceipt = columns.getOrNull(24)?.takeIf { it.isNotBlank() }
                    val osKeratometry = columns.getOrNull(25)?.takeIf { it.isNotBlank() }

                    val dateStr = columns.getOrNull(26)
                    val dateMillis = if (!dateStr.isNullOrBlank()) {
                        try {
                            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).parse(dateStr)?.time ?: System.currentTimeMillis()
                        } catch (e: Exception) {
                            System.currentTimeMillis()
                        }
                    } else {
                        System.currentTimeMillis()
                    }

                    val pr = Prescription(
                        patientId = patientId,
                        dateMillis = dateMillis,
                        odSph = odSph,
                        odCyl = odCyl,
                        odAxis = odAxis,
                        odAdd = odAdd,
                        odPd = odPd,
                        osSph = osSph,
                        osCyl = osCyl,
                        osAxis = osAxis,
                        odVasc = odVasc,
                        odVscc = odVscc,
                        odVabc = odVabc,
                        odVaPinhole = odVaPinhole,
                        osVasc = osVasc,
                        osVscc = osVscc,
                        osVabc = osVabc,
                        osVaPinhole = osVaPinhole,
                        binocularVabc = binocularVabc,
                        autorefractionReceipt = autorefractionReceipt,
                        keratometry = keratometry,
                        odAutorefractionReceipt = odAutorefractionReceipt,
                        odKeratometry = odKeratometry,
                        osAutorefractionReceipt = osAutorefractionReceipt,
                        osKeratometry = osKeratometry
                    )

                    repository.insertPrescription(pr)
                    importedPrescriptions++
                }

                onResult(true, "Successfully imported $importedPatients new patients and $importedPrescriptions prescriptions.")
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false, "Failed to parse CSV: ${e.localizedMessage}")
            }
        }
    }

    fun deletePrescription(id: Long) {
        viewModelScope.launch {
            repository.deletePrescriptionById(id)
        }
    }

    fun runAiExtraction(text: String?, image: Bitmap?, customApiKey: String? = null) {
        viewModelScope.launch {
            _isExtracting.value = true
            try {
                val result = GeminiClient.analyzePrescription(text, image, customApiKey)
                if (result != null) {
                    _extractedPrescription.value = result
                } else {
                    _extractionError.emit("Failed to parse prescription data. Please check image/text clarity.")
                }
            } catch (e: Exception) {
                Log.e("OpticalViewModel", "Error extracting prescription", e)
                _extractionError.emit(e.message ?: "An unexpected error occurred during extraction")
            } finally {
                _isExtracting.value = false
            }
        }
    }

    fun clearExtractedPrescription() {
        _extractedPrescription.value = null
    }

    // Helper to format phone number correctly (remove non-digits except +, and auto-format Iraqi numbers)
    fun formatPhoneNumber(phone: String): String {
        // Strip non-digit characters except +
        var cleaned = phone.filter { it.isDigit() || it == '+' }
        
        // Handle Iraqi phone number conversion
        if (cleaned.startsWith("+964")) {
            // Check if there's a leading 0 after the country code, e.g. +9640770...
            val afterCountry = cleaned.substring(4)
            if (afterCountry.startsWith("0")) {
                cleaned = "+964" + afterCountry.substring(1)
            }
        } else if (cleaned.startsWith("964")) {
            val afterCountry = cleaned.substring(3)
            if (afterCountry.startsWith("0")) {
                cleaned = "+964" + afterCountry.substring(1)
            } else {
                cleaned = "+964" + afterCountry
            }
        } else {
            // Strip any leading 0 first
            if (cleaned.startsWith("0")) {
                cleaned = cleaned.substring(1)
            }
            cleaned = "+964$cleaned"
        }
        return cleaned
    }

    // Messaging link generation helpers
    fun generateReceiptText(patient: Patient, prescription: Prescription): String {
        val formatVal = { v: Double? -> if (v == null) "—" else if (v > 0) String.format(java.util.Locale.US, "+%.2f", v) else String.format(java.util.Locale.US, "%.2f", v) }
        val odSection = "OD (Right Eye): SPH: ${formatVal(prescription.odSph)}, CYL: ${formatVal(prescription.odCyl)}, AXIS: ${prescription.odAxis ?: "—"}, ADD: ${formatVal(prescription.odAdd)}, PD: ${prescription.odPd ?: "—"}"
        val osSection = "OS (Left Eye):  SPH: ${formatVal(prescription.osSph)}, CYL: ${formatVal(prescription.osCyl)}, AXIS: ${prescription.osAxis ?: "—"}, ADD: ${formatVal(prescription.osAdd)}, PD: ${prescription.osPd ?: "—"}"

        val vaOdSect = if (!prescription.odVasc.isNullOrBlank() || !prescription.odVscc.isNullOrBlank() || !prescription.odVabc.isNullOrBlank() || !prescription.odVaPinhole.isNullOrBlank()) {
            "OD VA: VASC: ${prescription.odVasc ?: "—"}, VSCC: ${prescription.odVscc ?: "—"}, VABC: ${prescription.odVabc ?: "—"}, VAPinhole: ${prescription.odVaPinhole ?: "—"}"
        } else ""

        val vaOsSect = if (!prescription.osVasc.isNullOrBlank() || !prescription.osVscc.isNullOrBlank() || !prescription.osVabc.isNullOrBlank() || !prescription.osVaPinhole.isNullOrBlank()) {
            "OS VA: VASC: ${prescription.osVasc ?: "—"}, VSCC: ${prescription.osVscc ?: "—"}, VABC: ${prescription.osVabc ?: "—"}, VAPinhole: ${prescription.osVaPinhole ?: "—"}"
        } else ""

        val vaBinocularSect = if (!prescription.binocularVabc.isNullOrBlank()) {
            "Binocular VABC: ${prescription.binocularVabc ?: "—"}"
        } else ""

        val vaFullSection = if (vaOdSect.isNotEmpty() || vaOsSect.isNotEmpty() || vaBinocularSect.isNotEmpty()) {
            "\nVISUAL ACUITY:\n" + listOf(vaOdSect, vaOsSect, vaBinocularSect).filter { it.isNotEmpty() }.joinToString("\n") + "\n"
        } else ""

        val objectiveSection = if (
            !prescription.autorefractionReceipt.isNullOrBlank() || 
            !prescription.keratometry.isNullOrBlank() ||
            !prescription.odAutorefractionReceipt.isNullOrBlank() ||
            !prescription.odKeratometry.isNullOrBlank() ||
            !prescription.osAutorefractionReceipt.isNullOrBlank() ||
            !prescription.osKeratometry.isNullOrBlank()
        ) {
            val lines = mutableListOf<String>()
            prescription.autorefractionReceipt?.let { lines.add("Global Autorefraction: $it") }
            prescription.keratometry?.let { lines.add("Global Keratometry: $it") }
            if (!prescription.odAutorefractionReceipt.isNullOrBlank() || !prescription.odKeratometry.isNullOrBlank()) {
                lines.add("OD (Right Eye):")
                prescription.odAutorefractionReceipt?.let { lines.add("  - Autorefraction: $it") }
                prescription.odKeratometry?.let { lines.add("  - Keratometry: $it") }
            }
            if (!prescription.osAutorefractionReceipt.isNullOrBlank() || !prescription.osKeratometry.isNullOrBlank()) {
                lines.add("OS (Left Eye):")
                prescription.osAutorefractionReceipt?.let { lines.add("  - Autorefraction: $it") }
                prescription.osKeratometry?.let { lines.add("  - Keratometry: $it") }
            }
            "\nOBJECTIVE REFRACTOMETRY:\n" + lines.joinToString("\n") + "\n"
        } else ""

        return """
            👓 RX RECORDER RECEIPT 👓
            ----------------------------------------
            Patient: ${patient.fullName}
            Phone: ${patient.phoneNumber}
            DOB: ${patient.dateOfBirth}

            PRESCRIPTION:
            $odSection
            $osSection
            $vaFullSection
            $objectiveSection
            ORDER SUMMARY:
            Frame: ${prescription.frameModel ?: "Not Selected"}
            Lens Type: ${prescription.lensType ?: "Not Selected"}
            
            ${if (!prescription.notes.isNullOrBlank()) "Notes: " + prescription.notes else ""}
            
            Thank you for choosing RX Recorder!
        """.trimIndent()
    }

    fun generateShareText(patient: Patient, prescription: Prescription): String {
        val formatSph = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%+.2f", v) }
        val formatCyl = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%.2f", v) }
        val formatAxis = { v: Int? -> v?.toString() ?: "0" }
        val formatAdd = { v: Double? -> if (v == null || v == 0.0) "P" else String.format(java.util.Locale.US, "%+.2f", v) }
        val formatPd = { v: Double? -> v?.let { String.format(java.util.Locale.US, "%.0f", it) } ?: "0" }

        val currentDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

        return """
            ─────────────────────────────────────
                    Ahmed Optical
                  فحص النظر / پشکنینی چاو
            ─────────────────────────────────────

            Name / ناو: ${patient.fullName}

            Right Eye (R) / چاوی ڕاست:
            Sphere (Sph): ${formatSph(prescription.odSph)}
            Cylinder (Cyl): ${formatCyl(prescription.odCyl)}
            Axis (Ax): ${formatAxis(prescription.odAxis)}

            Left Eye (L) / چاوی چەپ:
            Sphere (Sph): ${formatSph(prescription.osSph)}
            Cylinder (Cyl): ${formatCyl(prescription.osCyl)}
            Axis (Ax): ${formatAxis(prescription.osAxis)}

            ADD (Near addition): ${formatAdd(prescription.odAdd)}
            PD (Pupillary distance): ${formatPd(prescription.odPd)} mm

            ─────────────────────────────────────
            Date: $currentDate  Signature: Ahmed Optical
        """.trimIndent()
    }

    fun getWhatsAppLink(patient: Patient, prescription: Prescription): String {
        val text = generateShareText(patient, prescription)
        val encodedText = URLEncoder.encode(text, "UTF-8")
        val cleanPhone = patient.phoneNumber.replace("+", "").replace(" ", "").replace("-", "")
        return "https://wa.me/$cleanPhone?text=$encodedText"
    }

    fun getViberLink(patient: Patient, prescription: Prescription): String {
        val text = generateShareText(patient, prescription)
        val encodedText = URLEncoder.encode(text, "UTF-8")
        return "viber://send?text=$encodedText"
    }

    fun getTelegramLink(patient: Patient, prescription: Prescription): String {
        val text = generateShareText(patient, prescription)
        val encodedText = URLEncoder.encode(text, "UTF-8")
        return "https://t.me/share/url?url=&text=$encodedText"
    }

    fun exportToJson(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val patientsList = allPatients.value
                val prescriptionsList = allPrescriptions.value

                val backupJson = org.json.JSONObject()

                // Serialize Patients
                val patientsArray = org.json.JSONArray()
                for (patient in patientsList) {
                    val patientJson = org.json.JSONObject().apply {
                        put("id", patient.id)
                        put("fullName", patient.fullName)
                        put("phoneNumber", patient.phoneNumber)
                        put("dateOfBirth", patient.dateOfBirth)
                        put("createdAtMillis", patient.createdAtMillis)
                    }
                    patientsArray.put(patientJson)
                }
                backupJson.put("patients", patientsArray)

                // Serialize Prescriptions
                val prescriptionsArray = org.json.JSONArray()
                for (pres in prescriptionsList) {
                    val presJson = org.json.JSONObject().apply {
                        put("id", pres.id)
                        put("patientId", pres.patientId)
                        put("dateMillis", pres.dateMillis)
                        
                        // OD Metrics
                        put("odSph", pres.odSph ?: org.json.JSONObject.NULL)
                        put("odCyl", pres.odCyl ?: org.json.JSONObject.NULL)
                        put("odAxis", pres.odAxis ?: org.json.JSONObject.NULL)
                        put("odAdd", pres.odAdd ?: org.json.JSONObject.NULL)
                        put("odPd", pres.odPd ?: org.json.JSONObject.NULL)

                        // OS Metrics
                        put("osSph", pres.osSph ?: org.json.JSONObject.NULL)
                        put("osCyl", pres.osCyl ?: org.json.JSONObject.NULL)
                        put("osAxis", pres.osAxis ?: org.json.JSONObject.NULL)
                        put("osAdd", pres.osAdd ?: org.json.JSONObject.NULL)
                        put("osPd", pres.osPd ?: org.json.JSONObject.NULL)

                        // VA Metrics
                        put("odVasc", pres.odVasc ?: org.json.JSONObject.NULL)
                        put("odVscc", pres.odVscc ?: org.json.JSONObject.NULL)
                        put("odVabc", pres.odVabc ?: org.json.JSONObject.NULL)
                        put("odVaPinhole", pres.odVaPinhole ?: org.json.JSONObject.NULL)
                        put("osVasc", pres.osVasc ?: org.json.JSONObject.NULL)
                        put("osVscc", pres.osVscc ?: org.json.JSONObject.NULL)
                        put("osVabc", pres.osVabc ?: org.json.JSONObject.NULL)
                        put("osVaPinhole", pres.osVaPinhole ?: org.json.JSONObject.NULL)
                        put("binocularVabc", pres.binocularVabc ?: org.json.JSONObject.NULL)

                        // Orders & Extras
                        put("frameModel", pres.frameModel ?: org.json.JSONObject.NULL)
                        put("lensType", pres.lensType ?: org.json.JSONObject.NULL)
                        put("notes", pres.notes ?: org.json.JSONObject.NULL)

                        // Autorefraction / Keratometry
                        put("autorefractionReceipt", pres.autorefractionReceipt ?: org.json.JSONObject.NULL)
                        put("keratometry", pres.keratometry ?: org.json.JSONObject.NULL)
                        put("odAutorefractionReceipt", pres.odAutorefractionReceipt ?: org.json.JSONObject.NULL)
                        put("odKeratometry", pres.odKeratometry ?: org.json.JSONObject.NULL)
                        put("osAutorefractionReceipt", pres.osAutorefractionReceipt ?: org.json.JSONObject.NULL)
                        put("osKeratometry", pres.osKeratometry ?: org.json.JSONObject.NULL)
                    }
                    prescriptionsArray.put(presJson)
                }
                backupJson.put("prescriptions", prescriptionsArray)

                val jsonString = backupJson.toString(2)
                onResult(true, jsonString)
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false, "Failed to export backup: ${e.message}")
            }
        }
    }

    fun importFromJson(jsonString: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                if (jsonString.isBlank()) {
                    onResult(false, "Selection is empty")
                    return@launch
                }
                val backupJson = org.json.JSONObject(jsonString)
                if (!backupJson.has("patients") || !backupJson.has("prescriptions")) {
                    onResult(false, "Invalid backup file: missing 'patients' or 'prescriptions' data structures.")
                    return@launch
                }

                val patientsArray = backupJson.getJSONArray("patients")
                val prescriptionsArray = backupJson.getJSONArray("prescriptions")

                val parsedPatients = mutableListOf<Patient>()
                val parsedPrescriptions = mutableListOf<Prescription>()

                fun getDoubleOrNull(obj: org.json.JSONObject, key: String): Double? {
                    return if (obj.isNull(key)) null else obj.optDouble(key).takeIf { !it.isNaN() }
                }
                fun getIntOrNull(obj: org.json.JSONObject, key: String): Int? {
                    return if (obj.isNull(key)) null else obj.optInt(key)
                }
                fun getStringOrNull(obj: org.json.JSONObject, key: String): String? {
                    return if (obj.isNull(key)) null else obj.optString(key).takeIf { it.isNotBlank() }
                }

                // 1. Process and parse patients
                for (i in 0 until patientsArray.length()) {
                    val patientObj = patientsArray.getJSONObject(i)
                    val patient = Patient(
                        id = patientObj.getLong("id"),
                        fullName = patientObj.getString("fullName"),
                        phoneNumber = patientObj.getString("phoneNumber"),
                        dateOfBirth = patientObj.getString("dateOfBirth"),
                        createdAtMillis = patientObj.optLong("createdAtMillis", System.currentTimeMillis())
                    )
                    parsedPatients.add(patient)
                }

                // 2. Process and parse prescriptions
                for (i in 0 until prescriptionsArray.length()) {
                    val presObj = prescriptionsArray.getJSONObject(i)
                    val pres = Prescription(
                        id = presObj.getLong("id"),
                        patientId = presObj.getLong("patientId"),
                        dateMillis = presObj.optLong("dateMillis", System.currentTimeMillis()),
                        
                        odSph = getDoubleOrNull(presObj, "odSph"),
                        odCyl = getDoubleOrNull(presObj, "odCyl"),
                        odAxis = getIntOrNull(presObj, "odAxis"),
                        odAdd = getDoubleOrNull(presObj, "odAdd"),
                        odPd = getDoubleOrNull(presObj, "odPd"),

                        osSph = getDoubleOrNull(presObj, "osSph"),
                        osCyl = getDoubleOrNull(presObj, "osCyl"),
                        osAxis = getIntOrNull(presObj, "osAxis"),
                        osAdd = getDoubleOrNull(presObj, "osAdd"),
                        osPd = getDoubleOrNull(presObj, "osPd"),

                        odVasc = getStringOrNull(presObj, "odVasc"),
                        odVscc = getStringOrNull(presObj, "odVscc"),
                        odVabc = getStringOrNull(presObj, "odVabc"),
                        odVaPinhole = getStringOrNull(presObj, "odVaPinhole"),

                        osVasc = getStringOrNull(presObj, "osVasc"),
                        osVscc = getStringOrNull(presObj, "osVscc"),
                        osVabc = getStringOrNull(presObj, "osVabc"),
                        osVaPinhole = getStringOrNull(presObj, "osVaPinhole"),

                        binocularVabc = getStringOrNull(presObj, "binocularVabc"),
                        frameModel = getStringOrNull(presObj, "frameModel"),
                        lensType = getStringOrNull(presObj, "lensType"),
                        notes = getStringOrNull(presObj, "notes"),

                        autorefractionReceipt = getStringOrNull(presObj, "autorefractionReceipt"),
                        keratometry = getStringOrNull(presObj, "keratometry"),
                        odAutorefractionReceipt = getStringOrNull(presObj, "odAutorefractionReceipt"),
                        odKeratometry = getStringOrNull(presObj, "odKeratometry"),
                        osAutorefractionReceipt = getStringOrNull(presObj, "osAutorefractionReceipt"),
                        osKeratometry = getStringOrNull(presObj, "osKeratometry")
                    )
                    parsedPrescriptions.add(pres)
                }

                // 3. Clear database & insert all items back
                repository.deleteAllPatients()

                for (p in parsedPatients) {
                    repository.insertPatient(p)
                }
                for (pr in parsedPrescriptions) {
                    repository.insertPrescription(pr)
                }

                onResult(true, "Successfully restored ${parsedPatients.size} patients and ${parsedPrescriptions.size} prescriptions from JSON backup.")
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false, "Failed to restore backup: ${e.message}")
            }
        }
    }

    fun checkAndTriggerWeeklyBackup(context: android.content.Context) {
        viewModelScope.launch {
            try {
                val lm = com.example.util.LocalBackupManager(context)
                if (lm.enableWeeklyBackup) {
                    val now = System.currentTimeMillis()
                    val lastWeekly = lm.lastWeeklyBackupTime
                    val sevenDaysMs = 7 * 24 * 60 * 60 * 1000L
                    if (now - lastWeekly >= sevenDaysMs) {
                        exportToJson { success, jsonText ->
                            if (success) {
                                lm.saveSilentBackup(jsonText)
                                lm.lastWeeklyBackupTime = now
                                android.widget.Toast.makeText(context, "Weekly auto-backup run successfully!", android.widget.Toast.LENGTH_SHORT).show()
                            } else {
                                android.util.Log.e("WeeklyBackup", "Weekly backup failed: $jsonText")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("WeeklyBackup", "Error checking weekly backup", e)
            }
        }
    }
}

class OpticalViewModelFactory(private val repository: OpticalRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(OpticalViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return OpticalViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
